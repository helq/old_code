from .base import AbstractElement
from .intervals import Interval

from enum import Enum
from queue import Queue

from typing import Dict, List, Any, Set  # noqa: F401
from typing import Optional


class AbstractState(AbstractElement):
    """
    This class defines an abstract state of the language. The language has only one entry
    point access which is called `root`. The state of the language is modeled as a
    directed graph where every node is either an object or a primitive.

    The primitives from the language are ints (and, in the future, bools).
    But in this Abstract Domain there are many "primitive" values:
    - An Abstract int element
    - Top = `Any` or `?`
    - Bottom (a value we hope never to encounter)
    - Undefined (all object attributes start undefined, this abstract value makes them
      explicit)

    An object is not a primitive value because it can point to other nodes, primitive
    values cannot.

    `root` can be a primitive value or it can be an object.
    """

    def __init__(self,
                 type_: 'NodeType',
                 optVal: Optional[Interval] = None
                 ) -> None:
        """
        There are only 5 possible values a node could be: AbsInt, Top, Bottom, Undefined,
        and Object.

        Only AbsInt can carry values.
        Only Objects can have attributes, references to other Objects.
        """
        if type_ == NodeType.AbsInt:
            if optVal is None:
                raise Exception("An Abstract Integer (Interval) type of node requires a "
                                "interval node")
        elif optVal is not None:
            raise Exception("Only nodes of type `AbsInt` can store a value")

        self.type = type_
        self.val = optVal

        if self.type == NodeType.Object:
            self.attrs = {}  # type: Optional[Dict[str, AbstractState]]
        else:
            self.attrs = None

    __top = None  # type: AbstractState
    __bottom = None  # type: AbstractState

    @classmethod
    def top(cls) -> 'AbstractState':
        """Returns the Top element from the lattice. """
        if cls.__top is None:
            cls.__top = cls(NodeType.Top)
        return cls.__top

    @classmethod
    def bottom(cls) -> 'AbstractState':
        """Returns the Bottom element from the lattice"""
        if cls.__bottom is None:
            cls.__bottom = cls(NodeType.Bottom)
        return cls.__bottom

    def is_top(self) -> bool:
        """Returns True if this object is the top of the lattice"""
        return self.type == NodeType.Top

    def is_bottom(self) -> bool:
        """Returns True if this object is the bottom of the lattice"""
        return self.type == NodeType.Bottom

    def smaller_than(self, other: 'AbstractState') -> bool:
        """Returns True if this object is "smaller" than other in the lattice"""
        raise NotImplementedError()

    def join(self, other: 'AbstractState') -> 'AbstractState':
        """Performs 'Least Upper Bound' operation between self and other"""
        raise NotImplementedError()

    def merge(self, other: 'AbstractState') -> 'AbstractState':
        """Performs 'Greatest Lower Bound' operation between self and other"""
        raise NotImplementedError()

    def widen_op(self, other: 'AbstractState') -> 'AbstractState':
        """Performs the Widen operation on self and other"""
        raise NotImplementedError()

    def narrow_op(self, other: 'AbstractState') -> 'AbstractState':
        """Performs the Narrow operation on self and other"""
        raise NotImplementedError()

    @property
    def __dot_val(self) -> str:
        if self.type == NodeType.AbsInt:
            return repr(self.val)
        elif self.type == NodeType.Top:
            return "⊤"
        elif self.type == NodeType.Bottom:
            return "⊥"
        elif self.type == NodeType.Undefined:
            return "💀"

        raise Exception("The node is not primitive. The node is of type {}".format(self.type))

    @property
    def __hashstr(self) -> str:
        return '_{:x}'.format(hash(self)).replace('-', '_')

    @property
    def dot_str(self) -> str:
        if self.type != NodeType.Object:
            return """
              digraph finite_state_machine {{
                rankdir=LR;
                size="8,5"
                node [shape = circle, fixedsize = true, width = .6, fontsize = 10];
                primitive [label="{}"];
              }}
              """.format(self.__dot_val)

        queue = Queue()  # type: Any
        queue.put(self)

        visited = set()  # type: Set[AbstractState]
        absnodes = []  # type: List[str]
        objs = []  # type: List[str]
        vertices = []  # type: List[str]
        absindex = 0

        while not queue.empty():
            node = queue.get()  # type: AbstractState
            if node in visited:
                continue

            visited.add(node)
            objs.append(
                '{} [label=""];'.format(node.__hashstr)
            )

            assert node.type == NodeType.Object
            assert node.attrs is not None

            for id_, n in node.attrs.items():
                if n.type == NodeType.Object:
                    if n not in visited:
                        queue.put(n)
                    vertices.append(
                        '{} -> {} [label="{}"];'.format(node.__hashstr, n.__hashstr, id_))
                else:
                    # print(n.type)
                    vertices.append(
                        '{} -> _z{} [label="{}"];'.format(node.__hashstr, absindex, id_))
                    absnodes.append('_z{} [label="{}"];'.format(absindex, n.__dot_val))
                    absindex += 1

        return """
         digraph finite_state_machine {{
           rankdir=LR;
           size="8,5"
           node [shape = doublecircle];
           {}
           node [shape = circle, fixedsize = true, width = .6, fontsize = 10];
           {}
           {}
         }}
         """.format(' '.join(objs), ' '.join(absnodes), ' '.join(vertices))


class NodeType(Enum):
    """
    A node in the abstract state of the program can only be one of the following:
    - An abstract int
    - Top = Any
    - Bottom
    - Undefined
    - Object
    """
    AbsInt = 0
    Top = 1
    Bottom = 2
    Undefined = 3
    Object = 4


# Run this with: python -m absintobjs.abstract_domains.object
if __name__ == '__main__':
    root = AbstractState(NodeType.Object)
    # root.attrs['a'] = AbstractState(NodeType.Object)
    assert isinstance(root.attrs, dict)
    root.attrs['a'] = AbstractState(NodeType.AbsInt, Interval(None, 10))
    root.attrs['b'] = AbstractState(NodeType.Object)
    root.attrs['c'] = root.attrs['b']
    assert isinstance(root.attrs['c'].attrs, dict)
    root.attrs['c'].attrs['a'] = AbstractState(NodeType.Top)
    root.attrs['c'].attrs['m'] = root.attrs['b']
    root.attrs['c'].attrs['n'] = root.attrs['a']
    root.attrs['x'] = AbstractState(NodeType.Undefined)
    print(root.dot_str)

    root = AbstractState(NodeType.AbsInt, Interval(None, 10))
    print()
    print(root.dot_str)
