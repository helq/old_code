ruby QR.rb > QR.py
python QR.py > QR.erl
escript QR.erl > QR.pl
perl QR.pl > QR.lua
lua QR.lua > QR.ml
ocaml QR.ml > QR.hs
runghc QR.hs > QR.c
gcc -Wall -o QR QR.c && ./QR > QR.java
javac QR.java && java -cp . QR > QR.bf
beef QR.bf > QR.sh
sh QR.sh > QR.ws
wspace QR.ws > QR.unl
unlambda QR.unl > QR2.rb
diff QR.rb QR2.rb

source --> http://catap.ru/blog/2009/11/09/one-japan-man/