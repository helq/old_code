from hypothesis import given
import hypothesis.strategies as st

import pytropos.internals.values as pv
from pytropos.internals.values.builtin_values import Int
from pytropos.internals.store.cell import Cell
from pytropos.internals.branch_node import BranchNode, global_branch


class TestCell:
    """Testing Cell capacity to save a PythonValue including setting and deleting"""

    @given(st.integers(), st.integers(min_value=1, max_value=100))
    def test_retrieve_value_cell_no_matter_branch(self, val: int, depth: int) -> None:
        BranchNode.current_branch = global_branch

        cell = Cell()
        cell.content = pv.int(val)

        assert cell.layerDepth() == 1

        cont = cell.content
        assert isinstance(cont.val, Int)
        assert cont.val.val == val

        for d in range(depth):
            BranchNode.current_branch = BranchNode.current_branch.newChild()

        cont = cell.content
        assert cell.layerDepth() == depth + 1
        assert isinstance(cont.val, Int)
        assert cont.val.val == val
