from numpy import *
angle(1+1j) # in radians
# 0.78539816339744828
angle(1+1j,deg=True) # in degrees
# 45.0

