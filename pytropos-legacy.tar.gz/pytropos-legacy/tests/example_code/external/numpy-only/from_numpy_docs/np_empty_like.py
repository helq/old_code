from numpy import *
a = array([[1,2,3],[4,5,6]])
empty_like(a) # uninitialized array with the same shape and datatype as 'a'
# array([[ 0, 25362433, 6571520],
#        [ 21248, 136447968, 4]])

