from numpy import *
ones(5)
# array([ 1., 1., 1., 1., 1.])
ones((2,3), int)
# array([[1, 1, 1],
#        [1, 1, 1]])

