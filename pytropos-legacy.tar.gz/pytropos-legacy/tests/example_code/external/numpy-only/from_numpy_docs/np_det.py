from numpy import *
from numpy.linalg import det
A = array([[1., 2.],[3., 4.]])
det(A) # determinant of square matrix
# -2.0

