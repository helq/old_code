from numpy import *
from numpy.random import bytes
print((repr(bytes(5)))) # string of 5 random bytes
# 'o\x07\x9f\xdf\xdf'
print((repr(bytes(5)))) # another string of 5 random bytes
# '\x98\xc9KD\xe0'

