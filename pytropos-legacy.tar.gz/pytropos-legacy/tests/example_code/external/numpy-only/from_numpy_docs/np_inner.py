from numpy import *
x = array([1,2,3])
y = array([10,20,30])
inner(x,y) # 1x10+2x20+3x30 = 140
# 140

