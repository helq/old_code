from numpy import *
a = array([-1.7, -1.5, -0.2, 0.2, 1.5, 1.7])
fix(a) # round a to nearest integer towards zero
# array([-1., -1., 0., 0., 1., 1.])

