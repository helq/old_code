from numpy import *
from numpy.random import permutation
permutation(4) # permutation of integers from 0 to 3
# array([0, 3, 1, 2])
permutation(4) # another permutation of integers from 0 to 3
# array([2, 1, 0, 3])
permutation(4) # yet another permutation of integers from 0 to 3
# array([3, 0, 2, 1])

