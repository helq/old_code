from numpy import *
from numpy.random import *
beta(a=1,b=10,size=(2,2)) # Beta distribution alpha=1, beta=10
# array([[ 0.02571091, 0.04973536],
#        [ 0.04887027, 0.02382052]])

