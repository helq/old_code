from numpy import *
from numpy.random import *
rand(3,2)
# array([[ 0.65159297, 0.78872335],
#        [ 0.09385959, 0.02834748],
#        [ 0.8357651 , 0.43276707]])

