from numpy import *
arcsin(array([0, 1]))
# array([ 0. , 1.57079633])

