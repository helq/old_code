from numpy import *
for index in ndindex(4,3,2):
    print(index)
# (0,0,0)
# (0,0,1)
# (0,1,0)
# ...
# (3,1,1)
# (3,2,0)
# (3,2,1)

