from numpy import *
cos(array([0, pi/2, pi]))
# array([ 1.00000000e+00, 6.12303177e-17, -1.00000000e+00])

