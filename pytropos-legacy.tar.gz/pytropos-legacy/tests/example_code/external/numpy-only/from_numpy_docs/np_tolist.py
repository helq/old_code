from numpy import *
a = array([[1,2],[3,4]])
a.tolist() # convert to a standard python list
# [[1, 2], [3, 4]]

