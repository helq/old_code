from numpy import *
a = array([-1.7, -1.5, -0.2, 0.2, 1.5, 1.7])
ceil(a) # nearest integers greater-than or equal to a
# array([-1., -1., -0., 1., 2., 2.])

