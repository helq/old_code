from numpy import *
arccos(array([0, 1]))
# array([ 1.57079633, 0. ])

