from numpy import *
a = array([-1.7, -1.5, -0.2, 0.2, 1.5, 1.7])
floor(a)
# array([-2., -2., -1., 0., 1., 1.]) # nearest integer smaller-than or equal to a # nearest integers greater-than or equal to a

