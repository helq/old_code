from numpy import *
x = array([2,3,2,1,0,3,4,0])
unique(x) # remove double values
# array([0, 1, 2, 3, 4])

