from numpy import *
multiply(array([3,6]), array([4,7]))
# array([12, 42])

