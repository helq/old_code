from numpy import *
from numpy.random import *
random_sample((3,2))
# array([[ 0.76228008, 0.00210605],
#        [ 0.44538719, 0.72154003],
#        [ 0.22876222, 0.9452707 ]])

