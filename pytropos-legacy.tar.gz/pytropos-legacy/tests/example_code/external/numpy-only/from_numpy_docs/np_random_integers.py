from numpy import *
from numpy.random import *
random_integers(-1,5,(2,2))
# array([[ 3, -1],
#        [-1, 0]])

