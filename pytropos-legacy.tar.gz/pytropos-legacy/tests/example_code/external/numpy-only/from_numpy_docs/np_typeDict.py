from numpy import *
typeDict['short']
# <type 'numpy.int16'>
typeDict['uint16']
# <type 'numpy.uint16'>
typeDict['void']
# <type 'numpy.void'>
typeDict['S']
# <type 'numpy.string_'>

