from numpy import *
empty(3) # uninitialized array, size=3, dtype = float
# array([ 6.08581638e+000, 3.45845952e-323, 4.94065646e-324])
empty((2,3),int) # uninitialized array, dtype = int
# array([[1075337192, 1075337192, 135609024],
#        [1084062604, 1197436517, 1129066306]])

