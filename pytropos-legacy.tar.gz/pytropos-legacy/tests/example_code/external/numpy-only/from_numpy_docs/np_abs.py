from numpy import *
abs(-1)
# 1
abs(array([-1.2, 1.2]))
# array([ 1.2, 1.2])
abs(1.2+1j)
# 1.5620499351813308

