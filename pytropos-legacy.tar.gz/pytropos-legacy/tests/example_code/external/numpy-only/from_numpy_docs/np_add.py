from numpy import *
add(array([-1.2, 1.2]), array([1,3]))
# array([-0.2, 4.2])
array([-1.2, 1.2]) + array([1,3])
# array([-0.2, 4.2])

