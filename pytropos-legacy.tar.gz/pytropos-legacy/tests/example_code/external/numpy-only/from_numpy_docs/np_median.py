from numpy import *
a = array([1,2,3,4,9])
median(a)
# 3
a = array([1,2,3,4,9,0])
median(a)
# 2.5

