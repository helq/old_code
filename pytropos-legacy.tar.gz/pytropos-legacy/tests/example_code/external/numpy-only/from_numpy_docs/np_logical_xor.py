from numpy import *
logical_xor(array([0,0,1,1]), array([0,1,0,1]))
logical_xor(array([False,False,True,True]), array([False,True,False,True]))

