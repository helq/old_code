from numpy import *
b = array([True, False, True, True])
sometrue(b)
# True
a = array([1, 5, 2, 7])
sometrue(a >= 5)
# True

