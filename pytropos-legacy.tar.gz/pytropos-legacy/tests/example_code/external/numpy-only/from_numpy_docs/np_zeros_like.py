from numpy import *
a = array([[1,2,3],[4,5,6]])
zeros_like(a) # with zeros initialised array with the same shape and datatype as 'a'
# array([[0, 0, 0],
#       [0, 0, 0]])
