All code in this folder was taken from:
https://scipy.github.io/old-wiki/pages/Numpy_Example_List
