from numpy import *
arctan2(array([0, 1]), array([1, 0]))
# array([ 0. , 1.57079633])

