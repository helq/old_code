from numpy import *
arctan(array([0, 1]))
# array([ 0. , 0.78539816])

