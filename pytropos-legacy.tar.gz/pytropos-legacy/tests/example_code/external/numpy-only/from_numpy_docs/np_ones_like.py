from numpy import *
a = array([[1,2,3],[4,5,6]])
ones_like(a) # ones initialised array with the same shape and datatype as 'a'
# array([[1, 1, 1],
#        [1, 1, 1]])

