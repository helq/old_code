from numpy import *
x = array([1,2,3])
y = array([10,20,30])
outer(x,y) # outer product
# array([[10, 20, 30],
#        [20, 40, 60],
#        [30, 60, 90]])

