from numpy import *
from numpy.random import *
poisson(lam=0.5, size=(2,3)) # poisson distribution lambda=0.5
# array([[2, 0, 0],
#        [1, 1, 0]])

