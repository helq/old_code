from numpy import *
arctanh(array([0, -0.5]))
# array([ 0. , -0.54930614])

