from numpy import *
x = array([1+2j,3+4j])
y = array([5+6j,7+8j])
vdot(x,y) # conj(x) * y = (1-2j)*(5+6j)+(3-4j)*(7+8j)
# (70-8j)

