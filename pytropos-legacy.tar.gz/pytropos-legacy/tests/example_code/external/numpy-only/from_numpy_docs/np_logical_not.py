from numpy import *
logical_not(array([0,1]))
logical_not(array([False,True]))

