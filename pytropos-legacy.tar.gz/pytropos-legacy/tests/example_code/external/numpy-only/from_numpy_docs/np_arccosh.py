from numpy import *
arccosh(array([e, 10.0]))
# array([ 1.65745445, 2.99322285])

