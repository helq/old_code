from numpy import *
arcsinh(array([e, 10.0]))
# array([ 1.72538256, 2.99822295])

