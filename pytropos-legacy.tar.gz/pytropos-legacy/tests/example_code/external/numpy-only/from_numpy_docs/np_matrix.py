from numpy import *
matrix('1 3 4; 5 6 9') # matrix is synonymous with mat
# matrix([[1, 3, 4],
#        [5, 6, 9]])

