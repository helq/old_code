from numpy import *
x = array([1,2,3])
y = array([4,5,6])
cross(x,y) # vector cross-product
# array([-3, 6, -3])

