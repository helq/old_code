from numpy import *
zeros(5)
# array([ 0., 0., 0., 0., 0.])
zeros((2,3), int)
# array([[0, 0, 0],
#        [0, 0, 0]])

