from numpy import *
b = array([True, False, True, True])
alltrue(b)
# False
a = array([1, 5, 2, 7])
alltrue(a >= 5)
# False

