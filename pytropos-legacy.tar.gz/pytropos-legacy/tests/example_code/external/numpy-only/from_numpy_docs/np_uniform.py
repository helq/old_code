from numpy import *
from numpy.random import *
uniform(low=0,high=10,size=(2,3)) # uniform numbers in range [0,10)
# array([[ 6.66689951, 4.50623001, 4.69973967],
#        [ 6.52977732, 3.24688284, 5.01917021]])

