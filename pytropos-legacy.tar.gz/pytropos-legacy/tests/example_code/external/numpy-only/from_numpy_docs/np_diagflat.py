from numpy import *
x = array([[5,6],[7,8]])
diagflat(x) # flatten x, then put elements on diagonal
# array([[5, 0, 0, 0],
#        [0, 6, 0, 0],
#        [0, 0, 7, 0],
#        [0, 0, 0, 8]])

