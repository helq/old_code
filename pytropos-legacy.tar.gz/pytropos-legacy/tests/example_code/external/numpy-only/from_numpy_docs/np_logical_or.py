from numpy import *
logical_or(array([0,0,1,1]), array([0,1,0,1]))
logical_or(array([False,False,True,True]), array([False,True,False,True]))

