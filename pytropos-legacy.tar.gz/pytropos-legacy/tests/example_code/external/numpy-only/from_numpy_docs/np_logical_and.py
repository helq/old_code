from numpy import *
logical_and(array([0,0,1,1]), array([0,1,0,1]))
# array([False, False, False, True], dtype=bool)
logical_and(array([False,False,True,True]), array([False,True,False,True]))
# array([False, False, False, True], dtype=bool)

