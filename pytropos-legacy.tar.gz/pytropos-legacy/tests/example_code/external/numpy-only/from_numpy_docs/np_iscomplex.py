import numpy as np
a = np.array([1,2,3.j])
np.iscomplex(a)
# array([False, False, True], dtype=bool)

