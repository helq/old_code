def fun(i = 2):
    # type: (int) -> int
    i = 10
    return i+3

i = 20
b = fun()
