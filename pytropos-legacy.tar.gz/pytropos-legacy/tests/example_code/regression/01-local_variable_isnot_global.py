def fun(i = 2):
    # type: (int) -> int
    i = 4
    return i+3

b = fun()
