Run `sphinx-apidoc -o . ../../pytropos` in this directory.

This will generate `modules.rst`, `pytropos.rst`, and others.

Then include `modules.rst` in your `index.rst` file.
