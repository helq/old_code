Specialized linter for tensor/array/matrix operations
=====================================================

Contents:

.. toctree::
   :maxdepth: 2

   modules


.. only:: html

   Indices and tables
   ==================

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
