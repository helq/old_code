import typing as ty

IntToFloatFun = ty.Callable[[int], float]

def print_globals(gls: dict) -> None:
    print("globals:", [g for g in sorted(gls.items()) if (len(g[0]) == 1 or g[0][0] != '_') and g[0] not in ['ty', 'IntToFloatFun', 'print_globals'] ])

def inside2() -> ty.Callable[[], None]:
    rr = 543
    def ff() -> None:
        nonlocal rr
        global size
        if rr % 5 == 2:
            rr *= 2
        rr += 1
        size = len(rr)/20  # type: ignore
    return ff

# original code
def inside() -> ty.Tuple[IntToFloatFun, ty.Callable[[], None]]:
    f = -2
    x = inside2()
    def fun(n: int) -> float:
        a = l
        x()
        m = 12
        # print("globals inside fun:", {g for g in globals().items() if g[0][0] != '_' and g[0] not in ['ty', 'IntToFloatFun'] })
        # print("locals inside fun:", locals())
        return (abs(n) - a) / (m + f)
    def fun2() -> None:
        nonlocal f
        f += 10
        x()
    return fun, fun2

a = 20.0
b = int(a)+2
l = 8
f1, f2 = inside()
for i in range(b):
    f2()
    if i%2==0:
        c = i*i
    else:
        c = i
        f2 = inside2()
        if c%3 == l%3:
            f1, _ = inside()

    print_globals(globals())

    n = f1(c)
    a += n*size  # type: ignore

del _

print_globals(globals())
