class A(object):
    myvar = "huh"
    def __init__(self, b: int, c: int, d: int) -> None:
        self.b = b
        self.c = c
        self.d = d
        self.m = b+c*d
    def huh(self) -> None:
        A.myvar += "!"

a = A(2,3,5)
print(a.m)

if False:
    a.m = 324
print(a.m)
print()

print( [e for e in dir(a) if e[0]!='_'] )
if False:
    a.test = 20
print( [e for e in dir(a) if e[0]!='_'] )
print()

print(A.myvar)
if False:
    a.huh()
print(A.myvar)
