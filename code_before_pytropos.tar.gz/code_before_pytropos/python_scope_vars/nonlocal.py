import typing as ty

import vars_lib as tl

vau = tl.Vault()
tl.Any.error_when_fail = True

@tl.Function
def test() -> ty.Tuple[tl.Value, tl.Value]:
    vau1 = tl.Vault(vau)
    vau1.add_local('m', 'll', 'rr')
    vau1['m'] = 10

    @tl.Function
    def ll() -> ty.Tuple[tl.Value, tl.Value]:
        vau2 = tl.Vault(vau1)
        vau2.add_local('m', 'tt', 'nn')

        @tl.Function
        def tt() -> None:
            vau3 = tl.Vault(vau2)
            vau3.add_nonlocal(('m', 1))
            print(vau3['m']-12)
            del vau3['m']
        vau2['tt'] = tt

        @tl.Function
        def nn() -> None:
            vau3 = tl.Vault(vau2)
            vau3.add_nonlocal(('m', 1))
            vau3['m'] = 21
            print(vau3['m'])
        vau2['nn'] = nn

        vau2['m'] = -90
        return vau2['tt'], vau2['nn']
    vau1['ll'] = ll

    @tl.Function
    def rr() -> None:
        vau2 = tl.Vault(vau1)
        vau2.add_nonlocal(('m', 1))
        print(vau2['m'])
    vau1['rr'] = rr

    return vau1['ll'](), vau1['rr']

vau['a'], vau['b'] = test()
# print("globals:", vau, vau.getClosures())
vau['a'][1]() # sets f.f.m to 21 and prints it -> 21
# print("globals:", vau, vau.getClosures())
vau['a'][0]() # prints f.f.m and deletes f.f.m -> 9
# print("globals:", vau, vau.getClosures())
vau['b']() # prints f.m -> 10
# print("globals:", vau, vau.getClosures())
try:
    vau['a'][0]() # tries to access f.f.m, but it has been deleted
except Exception as msg:
    print("failed, as expected:", msg)
# print("globals:", vau, vau.getClosures())
vau['a'][1]() # recreates f.f.m and prints it -> 21
# print("globals:", vau, vau.getClosures())
vau['b']() # prints f.m -> 10
# print("globals:", vau, vau.getClosures())
