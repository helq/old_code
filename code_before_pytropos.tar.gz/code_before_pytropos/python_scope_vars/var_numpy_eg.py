import numpy as np
import vars_lib as tl

var = tl.Vault()
tl.Any.error_when_fail = True

var['a'] = np.zeros( (10,5) )

var['m'] = 4 + 1
var['n'] = 0 + 0.0

with var.newBranch('if') as if_vault:
    var['n'] = 1

with var.newBranch('else') as else_vault:
    var['m'] = 6

if var['m'] == 5:
    var.replaceWithBranch(if_vault)
else:
    var.replaceWithBranch(else_vault)

var['b'] = np.ones( (var['m'], var['n']) )
var['res'] = np.dot(var['a'], var['b'])

print(var['res'])

var['var'] = True

if var['var']:
    var['b'] = np.zeros( (3, 10) )
    var['res'] = np.dot(var['b'], var['a'])

print(var['res'])
