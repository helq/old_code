from typing import Callable, Dict, Any

def afun(a: int) -> Dict[str, Any]:

    fun = lambda n: n**2  # type: Callable[[int], int]
    i = 3
    b = c = afun = None

    if a == fun(10):
        print("True branch", fun(4))
        def lastfun() -> int:
            return i * 8
        b = lastfun()
        afun = "hey"
    else:
        print("Else branch")
        c = 500

    return locals()

funlocals = afun(100)
print( "locals inside afun:", sorted(funlocals.items()) )
