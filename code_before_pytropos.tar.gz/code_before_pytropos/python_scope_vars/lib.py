from typing import Callable, Dict, Any, Tuple, Optional, TypeVar

DictVars = Dict[str, Any]

from enum import Enum

T = TypeVar('T')
BranchReturn = Tuple['ExitType', None, dict]

_SENTINEL = object()
# definition taken from https://stackoverflow.com/a/45661180
def make_cell(value: Any = _SENTINEL) -> Any:
    if value is not _SENTINEL:
        x = value
    return (lambda: x).__closure__[0]  # type: ignore

def __if(ifval: Any,
         ifbranch: Callable[[], BranchReturn],
         elsebranch: Callable[[], BranchReturn],  # TODO: I should be optional
         globs: DictVars,  # this is a reference to the globals of where this function was called, this function will modify that globals if the branches do
         locls: Optional[DictVars] = None
         ) -> Tuple[Dict[str, Any], Dict[str, Any]]:

    if locls is None:
        _if_glob = globs.copy()
        exec(ifbranch.__code__, _if_glob)
        _else_glob = globs.copy()
        exec(elsebranch.__code__, _else_glob)

        # TODO: check for what was modified in locals, and add modifications to
        # list modifications
        # TODO: check for what was modified in globals, check what needs to be
        # modified, and modify it (modify globs if necessary)
        # TODO: check for what was

        mod_to_local_vars = (_if_glob['__branch_locals'], _else_glob['__branch_locals'])

    else:
        _if_glob, _if_locls = globs.copy(), locls.copy()
        _if_locls['__f_function'] = ifbranch
        exec(exec_func_changing_closure, _if_glob, _if_locls)
        _else_glob, _else_locls = globs.copy(), locls.copy()
        _else_locls['__f_function'] = elsebranch
        exec(exec_func_changing_closure, _else_glob, _else_locls)

        # TODO: This is one of the many things to analyze deeply
        # print("return value:", _if_locls['__return'])
        # print(_if_locls)
        # print(_else_locls)

        mod_to_local_vars = (_if_locls['__branch_locals'], _else_locls['__branch_locals'])

    return mod_to_local_vars

from textwrap import dedent

exec_func_changing_closure = dedent("""
    __locals = locals()

    closure = []
    for c in __f_function.__code__.co_freevars:
        closure.append( lib.make_cell(__locals[c]) )

    newf = type(__f_function)(__f_function.__code__, globals(), closure=tuple(closure) )
    __ret_type, __return, __branch_locals = newf()
""")

class ExitType(Enum):
    RETURN = 0
    BREAK = 1
    CONTINUE = 2
