from typing import Tuple, Callable

def test() -> Tuple[Tuple[Callable, Callable], Callable]:
  m = 10
  def ll() -> Tuple[Callable, Callable]:
    def tt() -> None:
      nonlocal m
      print(m-12)
      del m
    def nn() -> None:
      nonlocal m
      m = 21
      print(m)
    m = -90
    return tt, nn
  def rr() -> None:
      nonlocal m
      print(m)
  return ll(), rr

a, b = test()
a[1]() # sets f.f.m to 21 and prints it -> 21
a[0]() # prints f.f.m and deletes f.f.m -> 9
b() # prints f.m -> 10
try:
    a[0]() # tries to access f.f.m, but it has been deleted
except Exception as msg:
    print("failed, as expected:", msg)
a[1]() # recreates f.f.m and prints it -> 21
b() # prints f.m -> 10
