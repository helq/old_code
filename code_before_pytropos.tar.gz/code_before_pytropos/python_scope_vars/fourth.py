from typing import Any

def test(m: Any, n: Any = 20) -> None:
    # print(globals())
    a = 1
    def test2(t: bool) -> None:
        print("test2 -> locals()", locals())
        print("test2 -> globals()", globals())
        if t:
            print(a, l)
    b = 2
    huh = locals()
    print("test -> locals()", huh)
    c = 3
    print("test -> locals()", huh)
    huh['d'] = 4
    print("test -> test2.__code__.co_names", test2.__code__.co_names)
    test2(True)
    print("test -> vars(test2)", vars(test2))
    # print(huh)
    print(d)

print("test.__code__.co_names", test.__code__.co_names)
print("test.__code__.co_nlocals", test.__code__.co_nlocals)

vars(test)['l'] = "yep"
test(3)
