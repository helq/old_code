import typing as ty

import vars_lib as tl

IntToFloatFun = ty.Callable[[int], float]

# # This always fails, but it doesn't in the translation (if no annotation is
# # given):
# mm = 0
# def f():
#   print(mm)
#   mm = 2
#
# # This error is due to the python interpreter, noticing that `mm` must be a
# # local variable because it is set inside of the function body
# # This is impossible to replicate with a Vault sadly T_T
# # This is one kind of bug that can only be caught at translation time, we must
# # indicate if the variable is local or not
#
# Proposed method of transformation:
# def f():
#    ...
#
#    vau1.add_local('mm')
#    vau1['print'](vau1['mm'])
#    vau1['mm'] = 2
#
# This transformation requires to notice which variables are set inside the
# scope of the function declaration (they shouldn't be tagged with 'global')
# On the same line, vau1.global should give us access only to the global
# (non-local) space

# code using a vault
vau = tl.Vault()
tl.Any.error_when_fail = True
# vau.vault[0].addLayer()

@tl.Function
def inside2() -> ty.Callable[[], None]:
    vau1 = tl.Vault(vau)
    vau1.add_local('f', 'rr', 'ff')
    vau1['rr'] = "SO WEIRD"
    @tl.Function
    def ff() -> None:
        vau2 = tl.Vault(vau1)
        vau2.add_nonlocal(('rr', 1))
        vau2.add_global('size')
        with vau2.newBranch('inside2_if') as if_vault:
            vau2['rr'] += '::'
        if len(vau2['rr']) % 5 == 2:
            vau2.replaceWithBranch(if_vault)
        vau2['rr'] += "!"
        vau2['size'] = len(vau2['rr'])/20
    vau1['ff'] = ff
    return vau1['ff'] # type: ignore
vau['inside2'] = inside2

@tl.Function
def inside() -> ty.Tuple[IntToFloatFun, ty.Callable[[], None]]:
    vau1 = tl.Vault(vau)
    vau1.add_global('inside2')
    vau1.add_local('f', 'x', 'fun', 'fun2')

    vau1['f'] = -2
    vau1['x'] = vau1['inside2']()

    @tl.Function
    def fun(*args: ty.Any) -> float:
        vau2 = tl.Vault(vau1)
        vau2.add_local('n', 'a', 'm')
        vau2.add_nonlocal(('f', 1), ('x', 1))
        vau2.add_global('l')
        # TODO: optionally add warning at checking number of args
        assert len(args) == 1
        vau2['n'] = args[0]

        vau2['a'] = vau2['l']
        vau2['x']()
        vau2['m'] = 12
        # print(id(vau2))
        # print("vault inside fun:", vau2.vault)
        return (abs(vau2['n']) - vau2['a']) / (vau2['m'] + vau2['f'])  # type: ignore
    vau1['fun'] = fun

    @tl.Function
    def fun2() -> None:
        vau2 = tl.Vault(vau1)
        vau2.add_nonlocal(('f', 1), ('x', 1))

        vau2['f'] += 10
        vau2['x']()
        # print("Vault inside f2:", vau2)
    vau1['fun2'] = fun2
    return vau1['fun'], vau1['fun2']
vau['inside'] = inside

vau['a'] = 20.0
vau['b'] = int(vau['a']) + 2
vau['l'] = 8

# print("Vault original", vau.vault)
# print()

vau['f1'], vau['f2'] = vau['inside']()
for i in range(vau['b']):
    vau['i'] = i

    vau['f2']()

    #if vau['i'] % 2 == 0:
    #    vau['c'] = vau['i']*vau['i']
    #    vau['f2']()
    #else:
    #    vau['c'] = vau['i']
    #    vau['f2'] = vau['inside2']()

    with vau.newBranch('if') as if_vault:
        # print("if branch")
        vau['c'] = vau['i']*vau['i']
    with vau.newBranch('else') as else_vault:
        # print("else branch")
        vau['c'] = vau['i']
        vau['f2'] = vau['inside2']()

        with vau.newBranch('else_if') as if2_vault:
            vau['f1'], vau['_'] = vau['inside']()

        if vau['c']%3 == vau['l']%3:
            vau.replaceWithBranch(if2_vault)

    print()
    print("Vault original", vau, vau.getClosures())
    print("Vault if", if_vault.val)
    print("Vault else", else_vault.val)
    print()

    if vau['i'] % 2 == 0:
        vau.replaceWithBranch(if_vault)
    else:
        vau.replaceWithBranch(else_vault)

    print("Vault original (modified)", vau, vau.getClosures())
    print()

    # TODO(helq): For typechecking there should be a function called merge or something

    vau['n'] = vau['f1'](vau['c'])
    vau['a'] += vau['n']*vau['size']

# del vau['_']

# print(id(vau))
# print()
print("globals:", vau)
# tl.global_branch.printTree()

#import gc
#gc.collect()
#
#print("Scopes in existance:", len(tl.Scope._Scope__existing_ids))  # type: ignore
#
#for scope in gc.get_objects():
#    if isinstance(scope, tl.Scope):
#        print(scope.id, scope)
#
# this is super hard, and kinda like black magic
# ([i for i in gc.get_objects() if isinstance(i, tl.Scope)])[3]
# gc.get_referrers( ([i for i in gc.get_objects() if isinstance(i, tl.Scope)])[3] )
