import sys
import ctypes
from types import FrameType

def hack():
    # type: (...) -> None
    # Get the frame object of the caller
    frame = sys._getframe(1)
    frame.f_locals['x'] = "hack!"
    frame.f_locals['m'] = "well"
    # Force an update of locals array from locals dict
    ctypes.pythonapi.PyFrame_LocalsToFast(ctypes.py_object(frame),
                                          ctypes.c_int(0))

def func():
    # type: (...) -> FrameType
    x = 1
    hack()
    print(x)
    print(locals())
    return sys._getframe(0)

frame = func()

print(frame.f_locals)
