from typing import Dict, List, Optional, Set, Tuple
import typing as ty


class Value(object):
    ...


class Any(Value):
    error_when_fail = False

    def checkErrorIfUsed(self) -> None:
        if Any.error_when_fail:
            raise Exception("Trying to use Any value")

    def __init__(self, *args: ty.Any, **kargs: ty.Any) -> None:
        if len(args) > 0:
            if Any.error_when_fail:
                raise Exception("Trying to construct Any value (with parms: {})".format(repr(args)))
        if Any.error_when_fail:
            raise Exception("Trying to construct Any value")

    def __call__(self, *args: ty.Any, **kargs: ty.Any) -> 'Any':
        self.checkErrorIfUsed()
        return self

    def __getattr__(self, name: str) -> 'Any':
        self.checkErrorIfUsed()
        return self

    def noop(self) -> 'Any':
        self.checkErrorIfUsed()
        return self

    def binop(self, other: ty.Any) -> 'Any':
        self.checkErrorIfUsed()
        return self

    __truediv__  = binop
    __rtruediv__ = binop
    __add__      = binop
    __radd__     = binop
    __sub__      = binop
    __rsub__     = binop
    __abs__      = noop

    def __repr__(self) -> str:
        return "Any()"

class Function(Value):
    def __init__(self, fun: ty.Callable) -> None:
        self.__fun = fun
        self.__closure = None # type: Optional[Vault]
        # This is the only introspection hack that may differ between implementations of python.
        # If this doesn't work in some python implementation, this should be rewritten in "pure"
        # python, it could be very simple if a function definition gets converted into this:
        #
        # def test():
        #   vau1 = tl.Vault(vau)
        #   def myfun(*args):
        #       ...
        #   return vau1, myfun
        #
        # the code below will only need to save each paramater from the tuple into the variables
        # __closure and __fun
        if fun.__closure__ is not None and len(fun.__closure__) > 0: # type: ignore
            assert len(fun.__closure__) == 1, (  # type: ignore
                "A function should only have a single nonlocal variable")
            clo = fun.__closure__[0].cell_contents # type: ignore
            assert isinstance(clo, Vault), "All nonlocal variables in functions should be Vault"
            self.__closure = clo

    @property
    def fun_closure(self) -> 'Optional[Vault]':
        return self.__closure

    def __call__(self, *args: ty.Any, **kargs: ty.Any) -> ty.Any:
        # TODO(helq): several todos:
        # should save the type of the arguments passed, also, should copy the type of return
        # if the code is run again with the same parameters, we don't need to run it again.
        # Probably two different variables:
        # - What happens when the function is called with Any() arguments, does it fail?
        # - What happens if the function is called with a specific set of arguments
        # Is the function calling itself recursevely, if yes, return Any() (probably)
        return self.__fun(*args, **kargs)


class MutObject(Value):
    def __init__(self, obj: ty.Any) -> None:
        object.__setattr__(self, "_MutObject__vault", Scope())
        object.__setattr__(self, "_MutObject__obj", obj)
        # TODO(helq): this is wrong!!, an object can access to attributes from
        # the class, but it overrides them
        for attr in [a for a in dir(obj) if a[0]!='_']:
            self.__vault[attr] = getattr(obj, attr)

    def __getattr__(self, key: str) -> ty.Any:
        return self.__vault[key]
    def __setattr__(self, key: str, val: ty.Any) -> None:
        self.__vault[key] = val
    def __repr__(self) -> str:
        return repr(self.__obj)

class Class(Value):
    def __init__(self, cls: ty.Any) -> None:
        object.__setattr__(self, "_Class__cls", cls)
        object.__setattr__(self, "_Class__vault", Scope())
        for attr in [a for a in dir(cls) if a[0]!='_']:
            self.__vault[attr] = getattr(cls, attr)

    def __getattr__(self, key: str) -> ty.Any:
        return self.__vault[key]
    def __setattr__(self, key: str, val: ty.Any) -> None:
        self.__vault[key] = val

    def __call__(self, *args: ty.Any, **kargs: ty.Any) -> ty.Any:
        # print("Creating object of type:", self.__cls.__name__)
        return MutObject(self.__cls(*args, **kargs))

class BranchNode(object):
    current_branch = None  # type: BranchNode

    def __init__(self,
                 parent: Optional['BranchNode'] = None,
                 name: Optional[str] = None) -> None:
        self.parent = parent
        self.children = []  # type: List[BranchNode]
        self.name = name
        if parent is None:
            self.generation = 1
        else:
            self.generation = parent.generation + 1
    def newChild(self, name: Optional[str] = None) -> 'BranchNode':
        child = BranchNode(self, name)
        self.children.append(child)
        return child
    # list with all anscestors and itself
    def anscestorsList(self) -> List['BranchNode']:
        ans = [None] *self.generation
        node = self  # type: Optional[BranchNode]
        i = self.generation-1
        while node is not None:
            ans[i] = node  # type: ignore
            node = node.parent
            i -= 1
        assert i == -1, "self.generation doesn't coincide with number of ancestors"
        return ans  # type: ignore
    # this function tells us the separation of self to other
    # returns a tuple where the first element tells us how many ancestors have
    # they in common the second element tells us how many parents up in the
    # tree we need to go up, and the third element tells us how many nodes down
    # from it we need to go
    def findDistanceToNode(self, other: 'BranchNode') -> Tuple[int, int, int]:
        self_ancestors = self.anscestorsList()
        other_ancestors = other.anscestorsList()

        same_ancestors = 0
        for i in range(min(len(self_ancestors), len(other_ancestors))):
            if self_ancestors[i] == other_ancestors[i]:
                same_ancestors += 1
            else:
                break

        up   = len(self_ancestors) - same_ancestors
        down = len(other_ancestors) - same_ancestors
        return same_ancestors, up, down

    def treeInList(self, level: Optional[int] = None) -> List[Tuple[int, 'BranchNode']]:
        if level is None:
            level = len(self.anscestorsList()) - 1
        tree = [(level, self)]
        for node in self.children:
            tree.extend( node.treeInList(level+1) )
        return tree

    def printTree(self) -> None:
        for level, node in self.treeInList():
            for i in range(level):
                print('| ', end='')
            print('+', node)

    def __repr__(self) -> str:
        if self.name is not None:
            return "<{}>.0x{:02x}".format(self.name, id(self))
        else:
            return "0x{:02x}".format(id(self))

global_branch = BranchNode(name='global')
BranchNode.current_branch = global_branch

# TODO(helq): implement Cell object. It should have a behaivor similar to
# `Scope`, in which it can create carry information about an object in memory
# different in each branch. The main information it can carry is how many
# references an object (and where are those references (the scopes ids)).
# It carries the information in different branches, and its updated each time
# when a scope adds it or deletes it.
#class Cell(object):
#    @property
#    def obj(self) -> ty.Any:
#        return self.__obj
#
#    def __init__(self, obj: ty.Any) -> None:
#        self.__obj = obj

# A frozen dict
class FrozenScope(dict):
    def __init__(self, dic: 'Scope') -> None:
        self.__id = dic.id
        super().__init__()
        for k,v in dic.items():
            super().__setitem__(k, v)

    @property
    def id(self) -> int:
        return self.__id

    def __setitem__(self, key: ty.Any, value: ty.Any) -> None:
        raise KeyError("No key can be set in a frozen dict")

    def __delitem__(self, key: ty.Any) -> None:
        raise KeyError("No key can be deleted in a frozen dict")

    def __repr__(self) -> str:
        return "FrozenScope(" + super().__repr__() + ")"

class Scope(object):
    __new_id = 0  # type: int
    # All Scope in existence!
    # Many are unreachable, usually the Garbage Collector doesn't kill them all
    # immediately. Thus, this is only an estimate of how many scopes (layerable
    # dict) are reachable.
    # len(__existing_ids) >= `num of reachable scopes`
    __existing_ids = set()  # type: Set[int]

    @classmethod
    def __getnewid(cls) -> int:
        toret = cls.__new_id
        cls.__new_id += 1
        return toret

    @property
    def id(self) -> int:
        return self.__id

    def __init__(self) -> None:
        self.__layers = [({}, set())]  # type: List[Tuple[Dict[str,ty.Any], Set[str]]]
        self.__branch = global_branch
        self.__id = id_ = Scope.__getnewid()
        Scope.__existing_ids.add(id_)
        if self.__branch != BranchNode.current_branch:
            self.__moveToNewBranch()

    def __del__(self) -> None:
        # print("I'm dying T_T ({})".format(self.__id))
        Scope.__existing_ids.remove(self.__id)

    def __getitem__(self, key: str) -> ty.Any:
        if self.__branch != BranchNode.current_branch:
            self.__moveToNewBranch()
        for dic, dels in reversed(self.__layers):
            if key in dels:
                raise KeyError("Key `{}` has been deleted from Scope".format(key))
            if key in dic:
                return dic[key]
        raise KeyError("Key `{}` isn't inside Scope".format(key))

    def __setitem__(self, key: str, value: ty.Any) -> None:
        if self.__branch != BranchNode.current_branch:
            self.__moveToNewBranch()
        if key in self.__layers[-1][1]:
            self.__layers[-1][1].remove(key)
        self.__layers[-1][0][key] = value

    def __delitem__(self, key: str) -> None:
        if self.__branch != BranchNode.current_branch:
            self.__moveToNewBranch()
        deleted = False
        # if key is in the last layer, remove it
        if key in self.__layers[-1][0]:
            del self.__layers[-1][0][key]
            deleted = True

        # if key appears on any other layer (not in the last because it has been
        # removed from it) then explicitely say it has been deleted
        if key in self:
            self.__layers[-1][1].add(key)
            deleted = True

        if not deleted:
            raise KeyError("Key `{}` isn't inside Scope".format(key))

    def __contains__(self, key: str) -> bool:
        if self.__branch != BranchNode.current_branch:
            self.__moveToNewBranch()
        for dic, dels in reversed(self.__layers):
            if key in dels:
                return False
            if key in dic:
                return True
        return False

    def items(self) -> ty.Iterable[Tuple[str, ty.Any]]:
        if self.__branch != BranchNode.current_branch:
            self.__moveToNewBranch()
        shown: Set[str] = set()
        for dic, dels in reversed(self.__layers):
            shown.update(dels)
            for key, value in dic.items():
                if key not in shown:
                    yield (key, value)
                    shown.add(key)

    def __repr__(self) -> str:
        return "Scope({"+ ', '.join(repr(k)+': '+repr(v) for k,v in self.items()) +"})"

    def __len__(self) -> int:
        return len(list(self.items()))

    def __length_hint__(self) -> int:
        if self.__branch != BranchNode.current_branch:
            self.__moveToNewBranch()
        # if nobody has toched anything inside the implementation this method
        # should return the same as __len__
        l = 0
        for dic, dels in self.__layers:
            l += len(dic) - len(dels)
        return l if l>0 else 0

    def __iter__(self) -> ty.Iterable[str]:
        if self.__branch != BranchNode.current_branch:
            self.__moveToNewBranch()
        shown: Set[str] = set()
        for dic, dels in reversed(self.__layers):
            shown.update(dels)
            for key, value in dic.items():
                if key not in shown:
                    yield key
                    shown.add(key)

    def addLayer(self) -> None:
        self.__layers.append( (dict(), set()) )

    def removeLayer(self) -> None:
        if len(self.__layers) == 1:
            raise Exception("Only one layer in Scope, it can't be removed")
        self.__layers.pop()

    def layerDepth(self) -> int:
        return len(self.__layers)

    def __moveToNewBranch(self) -> None:
        same, up, down = self.__branch.findDistanceToNode(BranchNode.current_branch)
        depth = self.layerDepth()
        if depth < same:
            for i in range(same-depth):
                self.addLayer()

        for i in range(up):
            self.removeLayer()
        for i in range(down):
            self.addLayer()

        self.__branch = BranchNode.current_branch

    # returns if something has been modified or not
    def updateAndDelete(self, other: Dict[str, ty.Any]) -> bool:
        modified = False

        deleted = set(self.__iter__()).difference(other.__iter__())
        for d in deleted:
            del self[d]
        for k,v in other.items():
            if k not in self or id(self[k]) != id(v):
                self[k] = v
                modified = True

        if len(deleted) > 0:
            modified = True
        return modified


T = ty.TypeVar('T')

class Ptr(ty.Generic[T]):
    def __init__(self, val: Optional[T] = None) -> None:
        self.__val = val

    @property
    def val(self) -> T:
        if self.__val is None:
            raise Exception("There is no value to return yet,"
                            " you haven't yet (probably) exited the scope")
        return self.__val

    @val.setter
    def val(self, val: T) -> None:
        self.__val = val

# Closure = List[Tuple[Tuple[str, ...], Scope]]
ClosureDict = Dict[int, FrozenScope]
VaultList = List[Dict[str, ty.Any]]

def extendMerge(dic: Dict[ty.Any, Set[str]], other: Dict[ty.Any, Set[str]]) -> None:
    for k,v in other.items():
        if k in dic:
            dic[k].update(v)
        else:
            dic[k] = v

class Vault(object):
    # __global_vault = None  # type: Optional[Vault]
    def __init__(self,
                 vault = None, # type: Union[Vault, None, List[Scope]]
                 branch_names = ['global'],  # type: List[str]
                 global_ = None  # type: Optional[bool]
                 ) -> None:
        if global_ is not None:
            self.__global = global_   # type: bool
        self.__locals    = set()  # type: Set[str]
        self.__globals   = set()  # type: Set[str]
        self.__nonlocals = {}     # type: Dict[str, int]
        self.__branch_diff = []   # type: List[Ptr[Tuple[VaultList, ClosureDict]]]
        self.__branch_names = branch_names[:]
        self.__next_branch_name = None  # type: Optional[str]
        # self.childVaults = set()  # type: Set[Vault]
        if vault is None:
            self.__vault: List[Scope] = [Scope()]
            self.__global = True
        elif isinstance(vault, Vault):
            # making copy of vault (contains the same elements but it's a different list)
            self.__vault = vault.__vault[:]
            self.__vault.append( Scope() )
            self.__global = False
        elif isinstance(vault, list) and all(isinstance(s, Scope) for s in vault):
            # making copy of vault (contains the same elements but it's a different list)
            assert len(vault) != 0, "Cannot create a vault with no scope"
            self.__vault = vault[:]
            self.__global = len(vault) == 1
        else:
            raise Exception("vault must be None, a Vault object,"
                            " or a list of LayerableDicts")
        # self.closures = self.__create_closures()  # type: List[Scope]
        # if Vault.__global_vault is None:
        #     Vault.__global_vault = self


    def __closuresInsideScope(self, scope: Scope, ignore: Set[int]) -> Dict[int, Scope]:
        ignore = ignore.copy()
        closures = dict()  # type: Dict[int, Scope]
        for key, val in scope.items():
            if isinstance(val, Function) and val.fun_closure is not None:
                vault = val.fun_closure
                vault_closures = vault.__getClosures(ignore)
                closures.update(vault_closures)
                ignore.update(vault_closures.keys())
            if isinstance(val, MutObject):
                closure = val._MutObject__vault
                if closure.id not in ignore:
                    closures[closure.id] = closure
                    ignore.add(closure.id)

        return closures


    def __getClosures(self, ignore: Optional[Set[int]] = None) -> Dict[int, Scope]:
        closures = dict()  # type: Dict[int, Scope]
        wasNone = ignore is None
        if ignore is None:
            ignore = set()
        else:
            ignore = ignore.copy()

        for scope in self.__vault:
            if scope.id not in ignore:
                closures[scope.id] = scope
                ignore.add(scope.id)

                closrs_scope = self.__closuresInsideScope(scope, ignore)
                ignore.update(closrs_scope.keys())
                closures.update(closrs_scope)

        if wasNone:
            # removing scopes to which I have direct access
            for scope in self.__vault:
                del closures[scope.id]

        return closures


    def getClosures(self) -> Dict[int, Scope]:
        return self.__getClosures()


    def __getitem__(self, key: str) -> ty.Any:
        if self.__global or key in self.__globals:
            scope_i = 0
        elif key in self.__nonlocals:
            assert len(self.__vault) > 2, "There are not enough scopes to declare a nonlocal variable"
            scope_i = self.__nonlocals[key]
        elif key in self.__locals:
            scope_i = -1
        else:
            # assuming is in global scope
            scope_i = 0
            # TODO(helq): add warning!!!
            # raise KeyError("The variable `{}` hasn't been defined as global, local or nonlocal".format(key))

        scope = self.__vault[scope_i]
        if key in scope:
            return scope[key]

        # TODO(helq): an error should be added to the list of errors, because
        # this variable doesn't exist
        # TODO(helq): check if what was passed is a builtin, if it is, maybe
        # you should return its typing version, just to check for correctness
        # of the call of the builtin
        return Any(key)

    def __setitem__(self, key: str, value: ty.Any) -> None:
        if self.__global or key in self.__locals:
            self.__vault[-1][key] = value
        elif key in self.__globals:
            self.__vault[0][key] = value
        elif key in self.__nonlocals:
            scope_i = self.__nonlocals[key]
            self.__vault[scope_i][key] = value
        else:
            raise KeyError("The variable `{}` hasn't been defined as global, local or nonlocal".format(key))

    def __delitem__(self, key: str) -> None:
        if self.__global or key in self.__globals:
            scope_i = 0
        elif key in self.__locals:
            scope_i = -1
        elif key in self.__nonlocals:
            scope_i = self.__nonlocals[key]
        else:
            raise KeyError("The variable `{}` hasn't been defined as global, local or nonlocal".format(key))

        if key in self.__vault[scope_i]:
            del self.__vault[scope_i][key]
        else:
            ...
            # TODO(helq): add warning to the list of warnings, the variable
            # cannot be deleted because it doesn't exists

    def __repr__(self) -> str:
        return "Vault([" + \
            ', '.join(
                ['{' +
                 ', '.join(sorted(repr(k)+': '+repr(v) for k,v in scope.items())) +
                 '}'
                 for scope in self.__vault]
            )+"])"

    def newBranch(self, branch_name: str) -> 'Vault':
        self.__next_branch_name = branch_name
        return self

    def __enter__(self) -> Ptr[Tuple[VaultList, ClosureDict]]:
        # print("Entering vault")
        if self.__next_branch_name is None:
            self.__branch_names.append('new_branch')
        else:
            self.__branch_names.append(self.__next_branch_name)
            self.__next_branch_name = None
        BranchNode.current_branch = BranchNode.current_branch.newChild('.'.join(self.__branch_names))
        # assert self.__branch_diff is None, "A branch diff is inside of Vault, shouldn't be"
        self.__branch_diff.append( Ptr() )
        return self.__branch_diff[-1]

    def __exit__(self, exc_type, exc_value, traceback) -> Optional[bool]:  # type: ignore
        # TODO(helq): check if something has been changed from the original vault
        assert len(self.__branch_diff) != 0, "Branch diff dissapeared, there is no way I can return the vault modifications done inside the branch"
        self.__branch_diff[-1].val = (
            [FrozenScope(scope) for scope in self.__vault],  # vault copy
            {id_: FrozenScope(scope) for id_, scope in self.getClosures().items()} # closures copy
        )
        self.__branch_diff.pop()
        assert BranchNode.current_branch.parent is not None, "Error trying to come back to previous branch state, unreachable"
        BranchNode.current_branch = BranchNode.current_branch.parent
        assert len(self.__branch_names) > 1, "There should be at least one branch name in the list of branch names"
        self.__branch_names.pop()

    def add_global(self, *keys: str) -> None:
        self.__globals.update(keys)
        for k in keys:
            assert k not in self.__nonlocals, \
                "Variable `{}` has already been declared as nonlocal".format(k)
            assert k not in self.__locals, \
                "Variable `{}` has already been declared as locals".format(k)
    def add_nonlocal(self, *keys: Tuple[str, int]) -> None:
        assert len(self.__vault) > 2, "A nonlocal variable (or a closure) can only be created when inside two levels of function declarations"
        max_depth = len(self.__vault) - 2
        for k,d in keys:
            assert 1<=d<=max_depth, "The selected scope for the nonlocal variable `{}` must be between 1 and {}, but I was given {}".format(k, max_depth, d)
            self.__nonlocals[k] = -d-1
        for k,d in keys:
            assert k not in self.__globals, \
                "Variable `{}` has already been declared as globals".format(k)
            assert k not in self.__locals, \
                "Variable `{}` has already been declared as locals".format(k)
    def add_local(self, *keys: str) -> None:
        self.__locals.update(keys)
        for k in keys:
            assert k not in self.__globals, \
                "Variable `{}` has already been declared as globals".format(k)
            assert k not in self.__nonlocals, \
                "Variable `{}` has already been declared as nonlocal".format(k)

    # TODO(helq): before performing this, check all objects manipulated inherit
    # from Value, if not, something went terribly wrong!
    def replaceWithBranch(self,
                          branch: Ptr[Tuple[VaultList, ClosureDict]]
                          ) -> None:
        somethingchanged = True
        # this is brute force, I don't know how to know which scopes need to be changed once other some function has changed
        while somethingchanged:
            # branch.val can throw an exception if nothing has been set inside
            # of it, this often happens if you try to examine its value before
            # exiting the branch
            somethingchanged = self.__replaceWithBranch(branch.val)

    # returns true if something was modified
    def __replaceWithBranch(self, branch: Tuple[VaultList, ClosureDict]) -> bool:
        modified = False

        vault, branch_closures = branch
        my_closures = self.getClosures()

        assert len(vault) == len(self.__vault), "The branch's vault has a different number of scopes than myself"

        for i, scope in enumerate(self.__vault):
            mod = scope.updateAndDelete(vault[i])
            if mod:
                modified = True

        # for each closure I have access
        for vs, closure in my_closures.items():
            # If there is a frozen closure from the branch that corresponds to
            # this closure, modify closure given the frozen closure
            if closure.id in branch_closures:
                mod = closure.updateAndDelete(branch_closures[closure.id])
                if mod:
                    modified = True

        return modified


if __name__ == "__main__":
    ld = Scope()
    ld['test'] = 20
    ld.addLayer()
    print(ld)
    ld['test'] = 10
    print(ld)
    ld.removeLayer()
    print(ld)
    del ld['test']
    ld.addLayer()
    ld['test'] = 3
    print(ld)
    ld.removeLayer()
    print(ld)

    node = BranchNode()
    n2 = node.newChild().newChild()
    n3 = node.newChild()
    print( node.findDistanceToNode(n2) )
    print( n2.findDistanceToNode(node) )
    print( n2.findDistanceToNode(n3) )
    n4 = n2.newChild().newChild()
    n5 = n2.newChild()
    print( n4.findDistanceToNode(n4) )
    print( n4.findDistanceToNode(n5) )
    print( n5.findDistanceToNode(n3) )
