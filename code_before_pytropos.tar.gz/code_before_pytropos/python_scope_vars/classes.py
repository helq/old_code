import typing as ty

import vars_lib as tl

vau = tl.Vault()
tl.Any.error_when_fail = True

@tl.Class
class A(object):
    myvar = "huh"
    def __init__(self, b: int, c: int, d: int) -> None:
        vau1 = tl.Vault(vau)
        vau1.add_local('self', 'b', 'c', 'd')
        vau1['self'], vau1['b'], vau1['c'], vau1['d'] = self, b, c, d
        vau1['self'].b = vau1['b']
        vau1['self'].c = vau1['c']
        vau1['self'].d = vau1['d']
        vau1['self'].m = vau1['b']+vau1['c']*vau1['d']
    def huh(self) -> None:
        vau1 = tl.Vault(vau)
        vau1.add_global('A')
        vau1['A'].myvar += "!"

vau['A'] = A

vau['a'] = vau['A'](2,3,5)
print(vau['a'].m)

with vau.newBranch('if1') as if_vault:
    vau['a'].m = 324
    # print( vau['a']._MutObject__vault )
print(vau['a'].m)
# print("if_vault:", if_vault.val)
print()

print( vau['a']._MutObject__vault )
with vau.newBranch('if1') as if_vault:
    vau['a'].test = 20
    # print( vau['a']._MutObject__vault )
print( vau['a']._MutObject__vault )
print()

print(vau['A'].myvar)
with vau.newBranch('if1') as if_vault:
    vau['a'].huh()
print(vau['A'].myvar)
