# taken from https://stackoverflow.com/a/7969953

print(globals())

class Test(object):
    a = 'one'
    b = 'two'
    def frobber(self):
        print(self.c)

print(globals())

t = Test()
huh = vars(t)
huh['c'] = 'three'
t.frobber()
