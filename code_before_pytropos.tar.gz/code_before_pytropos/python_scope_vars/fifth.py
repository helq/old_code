from typing import TYPE_CHECKING

import lib
import sys
import ctypes

if TYPE_CHECKING:
    from typing import Callable, Dict, Any, Tuple
    DictVars = Dict[str, Any]
    BranchReturn = Tuple[lib.ExitType, None, dict]

def afun(a: int) -> 'DictVars':

    fun = lambda n: n**2  # type: Callable[[int], int]
    i = 3
    b = c = afun = lastfun = None

    def __ifbranch() -> 'BranchReturn':
        print("True branch", fun(4))
        def lastfun() -> int:
            return i * 8
        b = lastfun()
        # print(globals())
        # print(locals())
        afun = "hey"

        # this could be replaced by returning or saving the frame of this call somewhere
        return lib.ExitType.RETURN, None, locals()

    def __elsebranch() -> 'BranchReturn':
        print("Else branch")
        c = 500

        return lib.ExitType.RETURN, None, locals()

    # TODO: __if should return one unique dictionary
    locls = locals()
    del locls['__ifbranch'], locls['__elsebranch']
    __if_change, __else_change = lib.__if(a == fun(10), __ifbranch, __elsebranch, globals(), locls)
    new_locls = __if_change if a == fun(10) else __else_change

    frame = sys._getframe(0)
    # restoring local variables defined/modified inside branch
    for __var_name, __var in new_locls.items():
        # print(__var_name, "=", repr(__var), "# value branch execution")
        # print(__var_name + "(before mod) = "+repr(locals()[__var_name]))
        # print(__var_name+" = __var # executing")
        # exec(__var_name+" = __var")  # this is super hacky, but there is no other way
        # print(__var_name + "(after exec) = "+repr(locals()[__var_name]))
        frame.f_locals[__var_name] = __var
        print(frame.f_locals)
    del __if_change, __else_change, __ifbranch, __elsebranch, locls, new_locls
    if "__var" in locals():
        ctypes.pythonapi.PyFrame_LocalsToFast(
            ctypes.py_object(frame),
            ctypes.c_int(0))
        del __var_name, __var

    return locals()

funlocals = afun(100)
print( "locals inside afun:", sorted(funlocals.items()) )
