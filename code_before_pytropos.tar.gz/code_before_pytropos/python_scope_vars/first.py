# taken from https://stackoverflow.com/a/7969953

def test():
    print(globals())
    a = 1
    b = 2
    huh = locals()
    print(huh)
    c = 3
    print(huh)
    huh['d'] = 4
    print(huh)
    print(d)

test()
