from typing import Dict, List, Optional, Set, Union, Iterable, Tuple
import typing as ty
import types
import sys

class FreezableDict(object):
    def __init__(self, dic: Union['FreezableDict',
                                  Dict[str, ty.Any],
                                  Iterable[Tuple[str, ty.Any]]
                                  ] = {},
                 frozen: bool = False) -> None:
        if isinstance(dic, dict):
            self.parent = None  # type: Optional[FreezableDict]
            self.dic = dic.copy()
        elif isinstance(dic, FreezableDict):
            dic.freeze()

            self.parent = dic
            self.dic = {}

            self.parent.__kids.add(self)
        elif isinstance(dic, types.GeneratorType):
            self.parent = None
            self.dic = dict(dic)
        else:
            Exception("FreezableDicts can only be build from "
                      "dictionaries or another FreezableDicts, as children")
        self.__frozen = frozen
        self.__kids = set()  # type: Set[FreezableDict]
        self.__deleted = set()  # type: Set[str]

    def __getitem__(self, key: str) -> ty.Any:
        # Checking something didn't go awry, if an object has been revived,
        # this object shouldn't work anymore
        if not self.areAncestorsFrozen():
            raise KeyError("An anscestor of FreezableDict has been revived! "
                           "You can't use this dict anymore")

        if key not in self.__deleted:
            if key in self.dic:
                return self.dic[key]
            elif self.parent is not None:
                return self.parent[key]

        raise KeyError("The key `{}` isn't inside of FreezableDict".format(key))

    def __setitem__(self, key: str, value: ty.Any) -> None:
        if self.__frozen == True:
            raise KeyError("Trying to set a variable in a frozen dict")

        if not self.areAncestorsFrozen():
            raise KeyError("An anscestor of FreezableDict has been revived! "
                           "You can't use this dict anymore")

        self.dic[key] = value

        if key in self.__deleted:
            self.__deleted.remove(key)

    def __delitem__(self, key: str) -> None:
        if not self.areAncestorsFrozen():
            raise KeyError("An anscestor of FreezableDict has been revived!"
                           "I am still connected to my revived ancestors! "
                           "You can't use this dict anymore")

        if key in self.dic:
            del self.dic[key]
        self.__deleted.add(key)

        raise KeyError("The key `{}` isn't inside of FreezableDict".format(key))

    # def __del__(self) -> None:
    #     print("I'm being deleted, well it was worthed")
    #     print("I was:", self)

    def __iter__(self) -> ty.Iterable[str]:
        shown: Set[str] = self.__deleted.copy()

        freezDict: Optional['FreezableDict'] = self
        while freezDict is not None:
            for i in freezDict.dic:
                if i not in shown:
                    yield i
                    shown.add(i)

            freezDict = freezDict.parent

    def __contains__(self, item: str) -> bool:
        if item in self.__deleted:
            return False

        freezDict: Optional['FreezableDict'] = self
        while freezDict is not None:
            if item in freezDict.dic:
                return True

            freezDict = freezDict.parent

        return False

    def __repr__(self) -> str:

        return "FreezableDict({{{}}}, frozen={})".format(
                    ', '.join(
                        [repr(i)+": "+repr(v) for i,v in sorted(self.items())]
                    ),
                    self.__frozen
        )

    def __len__(self) -> int:
        return len(list(self.items()))

    def areAncestorsFrozen(self) -> True:
        if self.parent is None:
            return True
        else:
            if not self.parent.isFrozen():
                return False
            else:
                return self.parent.areAncestorsFrozen()

    def isFrozen(self) -> bool:
        return self.__frozen

    def items(self) -> ty.Iterable[ty.Tuple[str, ty.Any]]:
        shown: Set[str] = self.__deleted.copy()

        freezDict: Optional['FreezableDict'] = self
        while freezDict is not None:
            for i, v in freezDict.dic.items():
                if i not in shown:
                    yield i, v
                    shown.add(i)

            freezDict = freezDict.parent

    def getKid(self) -> 'FreezableDict':
        return FreezableDict(self)

    def freeze(self) -> None:
        self.__frozen = True

    def unfreeze(self) -> None:
        for dic in self.__kids:
            # If there are 3 or less references to the kid object, it means
            # that the kid object is only referenced by parent, it can be
            # safely ignore, as it will be deleted after the current set is
            # deleted. (Why 3, well, two references are already in here, dic,
            # and in the call to getrefcount)
            if sys.getrefcount(dic) <= 3:
                dic.parent = None
            else:
                dic.parent = FreezableDict(self.items(), frozen=True)

        self.__kids = set()  # deleting old set, new set in place
        self.__frozen = False

    # We suppose that all kids from this Frozen Dictionary are not referenced
    def unsafe_unfreeze(self) -> None:
        self.__kids = set()
        self.__frozen = False

    def unsafe_remove(self) -> None:
        if self.parent is not None:
            self.parent.__kids.remove(self)
            self.parent = None
            #import gc
            #print(gc.get_referrers(self))
            #assert sys.getrefcount(self) <= 4 + len(self.__kids) , \
            #  "There should be at most 4 references to this object. " \
            #  "There are {} references".format(sys.getrefcount(self))

if __name__ == '__main__':
    fd = FreezableDict()
    fd["test"] = 20
    print("fd =", fd)
    fd2 = fd.getKid()
    fd2["test"] = 50.0
    fd2["tost"] = 21
    print("fd =", fd)
    print("fd2 =", fd2)
    ## run this
    # fd2.unsafe_remove()
    # del fd2
    ## or this
    # del fd2
    # fd.unfreeze()
    try:
        fd["tust"] = 21
    except Exception as msg:
        print("Well, fd is frozen")
    fd.unfreeze()
    fd["tust"] = 200
    print("fd =", fd)
    print("fd2 =", fd2)
