from typing import Callable

i = 5


def rrr() -> Callable[[], None]:
    def m() -> None:
        # global i
        # nonlocal i
        # i = 3
        r = [i+3 for i in range(8)]  # noqa
        print(i)
    i = 15
    return m


l = rrr()  # noqa
l()
l()

l2 = rrr()
l2()
l()
