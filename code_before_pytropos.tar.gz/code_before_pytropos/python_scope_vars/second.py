# taken from https://stackoverflow.com/a/7969953

class Test(object):
    print(globals())
    a = 'one'
    b = 'two'
    huh = locals()
    c = 'three'
    huh['d'] = 'four'
    print(huh)

Test()
print(globals())
