import typing as ty

# from tensorlint.internals.vault.cell import Cell

import tensorlint as tl
# import tensorlint.internals.vault.branch_node as branch_node

# code using a vault
vau = tl.Vault()
tl.Any.error_when_fail = True  # type: ignore
# vau.vault[0].addLayer()


@tl.Function
def inside2():
    # my_nonlocals = []

    def function():
        vau1 = tl.Vault(vau)
        # my_locals = {'f': Cell(), 'rr': Cell(), 'ff': Cell()}
        vau1.add_local('f', 'rr', 'ff')
        vau1['rr'] = tl.Int(543)

        @tl.Function
        def ff():
            nonlocals = ['rr']
            # my_nonlocals = [('rr', my_locals['rr'])]

            def function() -> None:
                vau2 = tl.Vault(vau1)
                vau2.add_nonlocal(*nonlocals)
                if_res = tl.eq(tl.mod(vau2['rr'], 5), 2)

                def if_branch():  # type: ignore
                    vau2['rr'] = tl.add(vau2['rr'], tl.Int(1))

                vau2.runIfBranching(if_res, if_branch)
                vau2['rr'] = tl.mul(vau2['rr'], tl.Int(1))
                vau2['size'] = len(vau2['rr'])/20

            return function, vau1.get_cells(nonlocals), ()

        vau1['ff'] = ff
        return vau1['ff']  # type: ignore

    return function, None, ()

print("YEP")

exit(1)

vau['inside2'] = inside2


# THINGS TO MODIFY TO MAKE THIS WORK:
# - Modify tl.Function to take a function that runs some code inside and gets the function
# - Modify vault to use cells (it shouldn't be a vault per level, only one is enough)

# Tasks after that:
# - vault should have access to __builtins__ but just supperficially
# - comparision between functions and their merging now possible

# Wait the whole piece of code is pure python, and even better it can be converted into
# Cython code!!! Which, probably means, some speed up!!! (or maybe not, add it to the list
# to do in the future)

@tl.Function
def inside():
    my_nonlocals = []

    def function():
        vau1 = tl.Vault(vau)
        vau1.add_global('inside2')
        # my_locals = {'f': Cell(), 'x': Cell(), 'fun': Cell(), 'fun2': Cell()}
        vau1.add_local('f', 'x', 'fun', 'fun2')

        vau1['f'] = -2
        vau1['x'] = vau1['inside2']()

        @tl.Function
        def fun():
            my_nonlocals = [('f', 1), ('x', 1)]
            # my_nonlocals = {'f': Cell(), 'x': Cell()}

            def function(*args: ty.Any) -> float:
                vau2 = tl.Vault(vau1)
                # my_locals = {'n': Cell(), 'a': Cell(), 'm': Cell()}
                vau2.add_local('n', 'a', 'm')
                vau2.add_nonlocal(*my_nonlocals)
                vau2.add_global('l')
                # TODO: optionally add warning at checking number of args
                assert len(args) == 1
                vau2['n'] = args[0]

                vau2['a'] = vau2['l']
                vau2['x']()
                vau2['m'] = 12
                # print(id(vau2))
                # print("vault inside fun:", vau2.vault)
                return (abs(vau2['n']) - vau2['a']) / (vau2['m'] + vau2['f'])  # type: ignore
            return function, my_nonlocals
        vau1['fun'] = fun

        @tl.Function
        def fun2():
            my_nonlocals = [('f', 1), ('x', 1)]
            # my_nonlocals = {'f': Cell(), 'x': Cell()}

            def function() -> None:
                vau2 = tl.Vault(vau1)
                vau2.add_nonlocal(*my_nonlocals)

                vau2['f'] += 10
                vau2['x']()
                # print("Vault inside f2:", vau2)

            return function, my_nonlocals

        vau1['fun2'] = fun2
        return vau1['fun'], vau1['fun2']

    return function, my_nonlocals


vau['inside'] = inside

vau['a'] = 20.0
vau['b'] = int(vau['a']) + 2
vau['l'] = 8

# print("Vault original", vau.vault)
# print()

vau['f1'], vau['f2'] = vau['inside']()
for i in range(vau['b']):
    vau['i'] = i

    vau['f2']()

    # if vau['i'] % 2 == 0:
    #     vau['c'] = vau['i']*vau['i']
    #     vau['f2']()
    # else:
    #     vau['c'] = vau['i']
    #     vau['f2'] = vau['inside2']()

    if_res = tl.Bool(vau['i'] % 2 == 0)

    def if_branch():  # type: ignore
        # print("if branch")
        vau['c'] = vau['i']*vau['i']
    def else_branch():  # type: ignore  # noqa
        # print("else branch")
        vau['c'] = vau['i']
        vau['f2'] = vau['inside2']()

        if_res = tl.Bool(vau['c'] % 3 == vau['l'] % 3)

        def if_branch():  # type: ignore
            vau['f1'], vau['_'] = vau['inside']()

        vau.runIfBranching(if_res, if_branch)

    # print()
    # print("Vault original", vau, vau.getClosures())

    vau.runIfBranching(if_res, if_branch, else_branch)

    # print("Vault original (modified)", vau, vau.getClosures())
    # print()

    vau['n'] = vau['f1'](vau['c'])
    vau['a'] += vau['n']*vau['size']

# del vau['_']

# print(id(vau))
# print()
print("globals:", vau)
# branch_node.global_branch.printTree()
