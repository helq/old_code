import tensorlint as tl
vau = tl.Vault()
tl.Any.error_when_fail = True  # type: ignore

def function(fun, *args):
  vau1 = tl.Vault(vau)
  vau1.add_locals('i', 'x')
  fun.load_args(vau1, args)
  return tl.add(vau1['i'], vau1['x'])
vau['myfun'] = tl.Function(function, None, ('i', 'x'))

print( vau['myfun'].call(tl.Int(2), tl.Int(6)) )

def function(fun, *args):
  vau1 = tl.Vault(vau)
  vau1.add_locals('i', 'rrr', 'j')
  fun.load_args(vau1, args)
  vau1['j'] = tl.Int(0)
  def function(fun, *args):
    vau2 = tl.Vault(vau1)
    # print(vau1._locals_cells)
    vau2.add_nonlocals('i', 'j')
    # fun.load_args(vau2, args)

    if_res = tl.eq(tl.mod(vau2['i'], tl.Int(2)), tl.Int(0))
    def if_branch():
      vau2['i'] = tl.floordiv(vau2['i'], tl.Int(2))
    vau2.runIfBranching(if_res, if_branch)

    vau2['i'] = tl.add(tl.mul(tl.Int(3), vau2['i']), tl.Int(1))

    if_res = tl.eq(tl.mod(vau2['i'], tl.Int(2)), tl.Int(0))
    def if_branch():
      vau2['j'] = tl.add(vau2['j'], tl.Int(1))
    def else_branch():
      vau2['j'] = tl.add(vau2['j'], tl.Int(2))
    vau2.runIfBranching(if_res, if_branch, else_branch)

    return tl.pow(vau2['i'], vau2['j'])
  vau1['rrr'] = tl.Function(function, vau1.get_cells(['i', 'j']), ())
  return vau1['rrr']
vau['fun2'] = tl.Function(function, None, ('i',))

vau['f'] = vau['fun2'].call(tl.Int(2))
print( vau['f'].call() )
print( vau['f'].call() )
print( vau['f'].call() )
print( vau['f'].call() )
