def myfun(i, x):
  return i + x
print(myfun(2, 6))

def fun2(i):
  j = 0
  def rrr():
    nonlocal i, j
    if i%2==0:
      i //= 2
    i = 3*i + 1
    if i%2==0:
      j += 1
    else:
      j += 2
    return i**j
  return rrr
f = fun2(2)

print(f())
print(f())
print(f())
print(f())
