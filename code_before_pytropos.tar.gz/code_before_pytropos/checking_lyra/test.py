a: List[int] = [0]
b: List[int] = a
x: int = int(input())
a[0]: int = x
print(b[0])
# show_store()
