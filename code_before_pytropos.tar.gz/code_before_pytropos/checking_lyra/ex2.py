a: int = int(input())
if 1 <= a <= 9:
    b: int = a
else:
    b: int = 0
print(b)