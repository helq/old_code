# I'm trying here to look how is casting done by mypy


class A(object):
    a = None  # type: int

    def __init__(self, a: int) -> None:
        self.a = a

    def __add__(self, other: 'A', param: bool = False) -> 'A':
        if param:
            return A(self.a * other.a)
        else:
            return A(self.a + other.a)

    def __repr__(self) -> str:
        return 'A('+repr(self.a)+')'


print((5).__add__(6))
# Yeah! This fails! Unless explicitely, a float doesn't get cast to an int
print(A(5.) + A(6))
print(A(5).__add__(A(6)))
print(A(5).__add__(A(6), True))


class B(object):
    a = None  # type: float

    def __init__(self, a: float) -> None:
        self.a = a

    def __add__(self, other: 'B', param: bool = False) -> 'B':
        if param:
            return B(self.a * other.a)
        else:
            return B(self.a + other.a)

    def __repr__(self) -> str:
        return 'B('+repr(self.a)+')'


print((5).__add__(6))
print(B(5.) + B(6.))
print(B(5.) + B(6))  # THIS SHOULDN'T BE ALLOWED, 6 is an INT!!
# print( B(5).__add__( B(6) ) )
# print( B(5).__add__( B(6), True ) )
