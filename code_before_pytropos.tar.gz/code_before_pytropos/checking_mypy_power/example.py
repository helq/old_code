from typing import Optional, Union

mmm = int


class A:
    def __init__(self):
        # type: (...) -> None
        pass


def test(a: mmm, b: float) -> float:
    # reveal_type(b)
    # reveal_type(a)
    # nnn = int
    # c : nnn = b
    # reveal_type(nnn)

    # a += b
    return a+2


def myfun(x: Optional[int]) -> int:
    # import math
    if x is None:
        return 20
    else:
        return x+x


def sndfn(x: Union[int, str]) -> Union[int, str]:
    return x + x


# reveal_type(test)

def pow(x: int, y: int) -> int:
    return x ** y


def squared(x: Union[float, int]) -> float:
    return x ** 2.0


if __name__ == '__main__':
    print(test(2, None))
    print(test(3, "unte"))
    print(test(3, 2))

    # m : List[Optional[int]] = [4, 3.1, None, A()]
    m = [4, 3.1, None, A()]
    # reveal_type(m)
    n = [4, 3.1]
    # reveal_type(n)
    r = [4, 3, "truen"]
    # reveal_type(r)

    print(pow(5, 2.1))
    print(squared(3))
    print(squared(3.0))
