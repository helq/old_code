#!/usr/bin/env python3

import math
from typing import Union, Optional, Callable

def notype(xd):
    return xd+2

def myfun(x: Optional[int]) -> int:
    import math
    if x is None:
        return 20
    else:
        return x+x

def sndfn(x: Union[int, str]) -> Union[int, str]:
    if isinstance(x, int):
        return x + x
    else:
        return x + x

afun: Callable[[int], int] = lambda x: x+x
# reveal_type( afun )

captain: str

# if __name__ == '__main__':
#     print( "hi and", myfun(None) )
#     print( "hi and", sndfn("test ") )
#     print(captain)
