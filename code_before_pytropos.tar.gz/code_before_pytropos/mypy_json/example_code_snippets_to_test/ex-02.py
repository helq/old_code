#!/usr/bin/env python3

class A:
  def __init__(self, data, tail=None):
    self.data : Any = data
    self.tail : A = tail
  def __repr__(self):
    if self.tail == None:
        return repr(self.data)
    else:
        return repr(self.data) + "->" + repr(self.tail)

def alternateReverse(a : A, b : A = None) -> A:
    if a == None: return b
    if a.tail == None: return A(a.data, b)
    return A(a.data, alternateReverse(a.tail.tail, A(a.tail.data, b)))

a = A(1)
reveal_type(a)
b = a
for i in range(2,10):
    b.tail = A(i)
    b = b.tail

a = 21

print(repr(a))
print(repr(alternateReverse(a)))
