from mypy import fastparse
from mypy import nodes as mn
# import mypy.types
import json
from typing import Union, Any, Dict, Set

visited: Set[int] = set()

# Trying to get hash of element, if it fails it will try to get a hash result
# of combining hashes from elems


def special_hash(e: Any) -> int:
    try:
        return hash(e)
    except Exception:
        return hash(tuple([special_hash(ee) for ee in dir(e) if ee[0] != '_']))

# TODO: search what kinds in mypy mean

# The use of Dict[str, Any] is unavoidable, if Any is changed to any other
# type the
# def todict(mypyobj : Union[mn.Context, dict, str, None, int, float, list, tuple]
#           ) -> Union[Dict[str, Any], str, None, int, float, list, tuple]:


def todict(mypyobj: Any) -> Union[Dict[str, Any], str, None, int, float, list, tuple]:
    # print(type(mypyobj).__name__, " ->")
    # toret = None
    if mypyobj is None:
        # print("<- None")
        return None

    if isinstance(mypyobj, int) or isinstance(mypyobj, float):  # this captures booleans too
        return mypyobj

    if isinstance(mypyobj, list):
        return [todict(obj) for obj in mypyobj]

    if isinstance(mypyobj, tuple):
        return tuple(todict(obj) for obj in mypyobj)

    if isinstance(mypyobj, set):
        return list(mypyobj)

    # Only used in MyPyFile objects which have an element (called alias_deps) of type dict
    if isinstance(mypyobj, dict):
        return {str(i): todict(x) for i, x in mypyobj.items()}

    # print( type(mypyobj) )
    # print( mypyobj )
    if isinstance(mypyobj, mn.Context) and special_hash(mypyobj) not in visited:
        visited.add(special_hash(mypyobj))

        obj_vars = [v for v in dir(mypyobj)
                    if v[:1] != '_'
                    and not callable(getattr(mypyobj, v))]

        # if I don't put the type here, mypy will infer that the type is Dict[str, str] :S
        contents: Dict[str, Any] = {
            'type_name_mypy': "{}.{}".format(type(mypyobj).__module__, type(mypyobj).__name__)
        }

        methods = ['name', 'fullname']  # methods to call if they exist

        contents.update({
            v: getattr(mypyobj, v)() for v in methods
            if v in dir(mypyobj) and callable(getattr(mypyobj, v))
        })

        ignore = [
            'FLAGS',  # Additional uncessary info from functions
            'imports',  # MypyFile have a separate list for imports, but it isn't that necessary
            'definition',  # recursive reference from mypy.types.CallableType to Node :S
            # we don't need to save this, this carries the same
            # information as type, the difference lies that `type` may
            # change depending on what the mypy inference algorithm does
            # 'unanalyzed_type',
            'mro'  # a variable used in type inference
            ]

        # print(type(mypyobj).__name__, obj_vars)
        # for v in obj_vars:
        #     if not v in ignore:
        #         var = getattr(mypyobj, v)
        #         # print("var: '{}' of type: '{}'".format(v, type(var).__name__))
        #         d = todict( var )
        #         contents[v] = d
        contents.update({
            v: todict(getattr(mypyobj, v)) for v in obj_vars
            if v not in ignore
        })

        return contents

    return str(mypyobj)


def _test1() -> None:
    file_name = './example_code_snippets_to_test/ex-02.py'
    ff = open(file_name, 'r').read()
    mypyfile = fastparse.parse(ff, file_name, None)

    print(json.dumps(todict(mypyfile), indent=1))


def _test2() -> None:
    from mypy import build, main
    # import os
    # import glob

    sources, options = main.process_options(
        ['example_code_snippets_to_test/ex-01.py'])
    print(sources)

    b = build.build(sources, options)
    messages = b.errors
    # print( b.files )
    d = todict(b.files['ex-01'])

    print(json.dumps(d, indent=1))
    # print( b.manager )
    print(messages)

    # cleaning computed types
    # for f in glob.glob('./.mypy_cache/**/ex-01.*.json'):
    #    os.remove(f)


if __name__ == '__main__':
    # _test1()
    _test2()
