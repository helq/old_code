from .base import AbstractElement

from typing import Optional


class Interval(AbstractElement):
    """Integer intervals Abstract Domain as defined in 'Principles of program Analisys'"""

    def __init__(self, start: Optional[int], end: Optional[int]) -> None:
        """
        start = None is interpreted as start = -inf
        end = None is interpreted as   end = inf
        """

        self.__start = start
        self.__end = end

    @property
    def start(self) -> Optional[int]:
        return self.__start

    @property
    def end(self) -> Optional[int]:
        return self.__end

    def __repr__(self) -> str:
        if self.is_bottom():
            return "{}"
        if self.start is not None and self.start == self.end:
            return "{"+repr(self.start)+"}"  # e.g., {3}

        return "[{},{}]".format(
            '-inf' if self.start is None else self.start,
            'inf' if self.end is None else self.end
        )

    __top = None  # type: Interval
    __bottom = None  # type: Interval

    @classmethod
    def top(cls) -> 'Interval':
        """Returns interval [-inf, inf]"""
        if cls.__top is None:
            cls.__top = cls(None, None)

        return cls.__top

    @classmethod
    def bottom(cls) -> 'Interval':
        """Returns empty interval. [1, 0]"""
        if cls.__bottom is None:
            cls.__bottom = cls(1, 0)

        return cls.__bottom

    def is_top(self) -> bool:
        """Checks if interval is [-inf, inf]"""
        return self.start is None \
            and self.end is None

    def is_bottom(self) -> bool:
        """Checks if interval is empty"""
        return self.start is not None \
            and self.end is not None \
            and self.start > self.end

    def smaller_than(self, other: 'Interval') -> bool:
        """Comparing if self is contained inside other. Examples:
            [2, 10]  <= [1,10]
            [2, 10]  <= [1,inf]
            [3, 8]   <= [inf,10]
            [inf, 8] <= [inf,10]
            [inf, 8] <= [inf,inf]
        """

        # Checking if self.start >= other.start
        # It's a little long because we need to check for the new value -inf (represented
        # by None)
        if self.start is None:  # self.start = -inf
            if other.start is not None:  # other.start > -inf  =>  self.start < other.start
                return False
        else:
            if other.start is not None \
               and self.start < other.start:
                return False

        # Checking if self.end <= other.end
        if self.end is None:  # self.end = inf
            if other.end is not None:  # other.end < inf  =>  self.end > other.end
                return False
        else:
            if other.end is not None \
               and self.end > other.end:
                return False

        return True

    def join(self, other: 'Interval') -> 'Interval':
        """Performs 'Least Upper Bound' operation between self and other"""
        start = None  # type: Optional[int]
        end = None  # type: Optional[int]

        if self.is_bottom():
            return other
        if other.is_bottom():
            return self

        # finding min(self.start, other.start)
        if self.start is not None and other.start is not None:
            start = min(self.start, other.start)

        # finding max(self.end, other.end)
        if self.end is not None and other.end is not None:
            end = max(self.end, other.end)

        return Interval(start, end)

    def merge(self, other: 'Interval') -> 'Interval':
        """Performs 'Greatest Lower Bound' operation between self and other"""
        start = None  # type: Optional[int]
        end = None  # type: Optional[int]

        if self.is_bottom() or other.is_bottom():
            return Interval.bottom()

        # finding max(self.start, other.start)
        if self.start is None:
            start = other.start
        else:
            if other.start is None:
                start = self.start
            else:
                start = max(self.start, other.start)

        # finding min(self.end, other.end)
        if self.end is None:
            end = other.end
        else:
            if other.end is None:
                end = self.end
            else:
                end = min(self.end, other.end)

        return Interval(start, end)

    def widen_op(self, other: 'Interval') -> 'Interval':
        """Performs the Widen operation on self and other"""
        raise NotImplementedError()

    def narrow_op(self, other: 'Interval') -> 'Interval':
        """Performs the Narrow operation on self and other"""
        raise NotImplementedError()


# Run this with: python -m absintobjs.abstract_domains.intervals
if __name__ == '__main__':
    a = Interval(0, 0)
    b = Interval(0, 10)
    c = Interval(2, 4)
    bottom = Interval.bottom()
    top = Interval.top()
    print("{} <= {}  ==  {}".format(a, b, a.smaller_than(b)))
    print("{} <= {}  ==  {}".format(a, bottom, a.smaller_than(bottom)))
    print("{} <= {}  ==  {}".format(a, top, a.smaller_than(top)))
    print("join({}, {})  ==  {}".format(a, bottom, a.join(bottom)))
    print("join({}, {})  ==  {}".format(a, top, a.join(top)))
    print("join({}, {})  ==  {}".format(a, c, a.join(c)))
    print("merge({}, {})  ==  {}".format(a, bottom, a.merge(bottom)))
    print("merge({}, {})  ==  {}".format(a, top, a.merge(top)))
    print("merge({}, {})  ==  {}".format(a, c, a.merge(c)))
    # AbstractElement()  # this is an error
