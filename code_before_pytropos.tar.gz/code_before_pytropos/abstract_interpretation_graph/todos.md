- Merge (and, possibly, join) two elements of the Abstract Domain
- Implement widenning operator (hard)
- See how to prove soundness of the translation (you need to define well the semantics of
    the language, define, probably, a galois connection, and show that all semantics are
    correctly defined in the abstract domain. Proof too that merge, join, and widenning
    work as accordingly)
- graph1 must be the same as graph2
