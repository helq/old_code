#!/usr/bin/env bash

gnuplot create_svgs.gpi
./svgs_to_pdfs.sh
