class ExecutableComments {
    public static void main(String... args) {   
        // The comment below is no typo.    
        // \u000d System.out.println("This Comment Executed!"); 
    }
}
