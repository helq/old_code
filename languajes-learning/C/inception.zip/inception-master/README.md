Programmatic representation of the Brilliant movie: INCEPTION by the Genius Director THY name is Christopher Nolan!
My tribute to Nolan in "C" Language and a bit of assembly (x86) as the inception is done using x86 code morphing so that Fischer wakes up thinking that the thought was originated from his mind. Running the program would unravel the entire sequence in the movie. Reading the code would explain the movie Programmatically.

In order to compile the code, just type: `make`
And run the code by typing: `./inception` ,
to see the sequencing in the movie and have the code exit with Fischers Inception thought planted by the Inception team!

- [Karthick] [email]

[email]: mailto:a.r.karthick@gmail.com 
