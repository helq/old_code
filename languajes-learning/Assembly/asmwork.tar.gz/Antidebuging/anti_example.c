#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <sys/ptrace.h>

int main(int argc, char **argv){
    if(argc != 2){
        printf("%s <contraseña>\n", argv[0]);
        exit(0);
    }

    if (ptrace(PTRACE_TRACEME, 0, 0, 0) == -1){
        printf( "Debuggers no, gracias\n" );
        exit(1);
    }

    char passwd[12];
    int i;

    memset(passwd, '\0', 12);
    for( i = 0; i < 11; i++ ){
        passwd[i] = i<5?i*2+0x30:i<10?i*2+0x41:i+0x61;
    }

    printf("%s\n",strcmp(argv[1],passwd)?"Error :/":"OK");
}