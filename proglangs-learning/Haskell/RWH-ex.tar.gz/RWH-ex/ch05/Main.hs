module Main where

import SimpleJSON (JValue(..))
import PrettyJSON (renderJValue)
import Prettify (pretty, compact)

main = putStrLn $ pretty 20 $ renderJValue $ JObject [("foo", JNumber 1), ("bar", JBool False)]
