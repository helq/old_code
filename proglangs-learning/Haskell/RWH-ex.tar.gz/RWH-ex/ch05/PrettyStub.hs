module PrettyStub where

import SimpleJSON

data Doc = ToBeDefined
         deriving (Show)

char :: Char -> Doc
char c = undefined

--string :: String -> Doc
--string str = undefined

text :: String -> Doc
text str = undefined

double :: Double -> Doc
double num = undefined

(<>) :: Doc -> Doc -> Doc
a <> b = undefined

hcat :: [Doc] -> Doc
hcat xs = undefined

fsep :: [Doc] -> Doc
fsep xs = undefined
