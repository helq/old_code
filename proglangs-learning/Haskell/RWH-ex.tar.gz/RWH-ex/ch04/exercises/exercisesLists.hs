-- by helq

import Data.Char (digitToInt, isSpace)
import Data.List (foldl')

asInt  :: String -> Integer
asInt ""        = 0
asInt xxs@(x:xs) = 
    case x of
        '-'  -> negate $ asInt' xs
        '+'  ->          asInt' xs
        _    ->          asInt' xxs
      where asInt' xs = foldl' (\x y->x*10 + fromIntegral (digitToInt y)) 0 xs

-- original function asInt: asInt xs = foldl (\x y->x*10 + digitToInt y) 0 xs

myConcat :: [[a]] -> [a]
myConcat xss = foldr (++) [] xss

myTakeWhile      :: (a -> Bool) -> [a] -> [a]
myTakeWhile f xs = foldr g [] xs
    where g x y | f x       = x : y
                | otherwise = []

myGroupBy f xs = foldr g [] $ map (:[]) xs
    where g [x]  []     = [[x]]
          g [x] ((y:ys):yss)
            | f x y     = (x:y:ys):yss
            | otherwise = [x]:(y:ys):yss

myAny f xs = foldl' g False xs
    where g x y | f y       = True
                | otherwise = x

myAll f xs = foldl' g True xs
    where g x y | f y       = x
                | otherwise = False

myRepeat x = foldr (\_ xs->x:xs) [] [1..]

myCycle xs = foldr (\_ ys->xs++ys) [] [1..]

myWords    :: String -> [String]
myWords xs = foldr g [] xs
    where g x []        = [[x]]
          g x (y:ys)
            | isSpace x = []:y:ys
            | otherwise = (x:y):ys

myUnlines    :: [String] -> String
myUnlines xs = foldl' (\x y->x++y++"\n") "" xs
