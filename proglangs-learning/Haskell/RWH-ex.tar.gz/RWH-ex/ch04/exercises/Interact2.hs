-- file: ch04/InteractWith.hs

import System.Environment (getArgs)

interactWith function inputFile outputFile = do
    input <- readFile inputFile
    writeFile outputFile (function input)

main = mainWith myFunction
    where mainWith function = do
            args <- getArgs
            case args of
              [input,output] -> interactWith function input output
              _ -> putStrLn "error: exactly two arguments needed"
          myFunction = transLines

transLines      :: String -> String
transLines text = unlines $ transpose'' $ lines text
    where transpose'' txt = take (maximum (map length txt))
                                 $ transpose' $ map (++ repeat ' ') txt

transpose' [xs]     = map (:[]) xs
transpose' (xs:xss) = zipWith sinSpaces xs $ transpose' xss
    where sinSpaces ' ' " " = " " -- Spanglish
          sinSpaces x   " " = [x]
          sinSpaces x   xs  = x:xs


transpose          :: [[a]] -> [[a]] -- original by helq
transpose [xs]     = map (:[]) xs
transpose (xs:xss) = zipWith (:) xs $ transpose xss
