-- file: ch07/toupper-imp.hs
import System.IO
import Data.Char(toUpper)
import System.Directory

main :: IO ()
main = do 
       inh <- openFile "input.txt" ReadMode
       --outh <- openFile "output.txt" WriteMode
       
       isSeekIn <- hIsSeekable inh
       print isSeekIn

       hSeek inh AbsoluteSeek 30
       hSeek inh RelativeSeek (-2)

       ch <- hGetChar inh

       hSeek inh SeekFromEnd (-1)

       ch2 <- hGetChar inh

       n <- hTell inh
       print (n, ch, ch2)

       hClose inh


       hSetBuffering stdin NoBuffering
       getContents >>= writeFile "test.txt" . take 10

       --hClose outh

       --tmpDir <- getTemporaryDirectory
       --(tmpN, tmph) <- openTempFile tmpDir "temp.txt"
       --print tmpN
       --hClose tmph

--mainloop :: Handle -> Handle -> IO ()
--mainloop inh outh = 
--    do ineof <- hIsEOF inh
--       if ineof
--           then return ()
--           else do inpStr <- hGetLine inh
--                   hPutStrLn outh (map toUpper inpStr)
--                   mainloop inh outh
