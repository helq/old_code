
data MyTree a = MyNode a (Maybe (MyTree a)) (Maybe (MyTree a))
                deriving (Show)

-- file: ch03/Tree.hs
data Tree a = Node a (Tree a) (Tree a)
            | Empty
              deriving (Show)

data Various a b = Jum a | Fus b | Ban a b | Nun

--data MyIntegral a = Jas (Integral a => a)

type AssocList a b = [(a,b)]

height :: Integral a => Tree t -> a
height Empty = 0
height (Node x a b)
    | ha > hb   = ha + 1
    | otherwise = hb + 1
   where ha = height a
         hb = height b
