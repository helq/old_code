-- file: ch03/BogusPattern.hs
data Fruit = Apple | Orange
    deriving (Show)

apple = "apple"
orange = "orange"

whichFruit :: String -> Fruit

whichFruit f
    | f == apple = Apple
    | f == orange = Orange
