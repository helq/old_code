-- file: ch03/ListADT.hs (Algebraic Data Type)

data List a = a :=: List a | Nil

instance Show a => Show (List a) where
    show Nil = "[]"
    show bs  = '[' : myShow bs
      where myShow Nil         = "]"
            myShow (b :=: Nil) = show b ++ "]"
            myShow (b :=: bs)  = show b ++ ',' : myShow bs

infixr 5 :=:

fromList (b :=: bs) = b : fromList bs
fromList Nil        = []

fromlist (x:xs) = x :=: fromlist xs
fromlist []     = Nil
