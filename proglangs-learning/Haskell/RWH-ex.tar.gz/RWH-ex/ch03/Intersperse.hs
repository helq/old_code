-- file: ch03/Intersperse.hs

intersperse :: a -> [[a]] -> [a]
intersperse k ys = inter ys
    where inter [y]    = y
          inter (y:ys) = y ++ k : inter (ys)
          inter []     = []
