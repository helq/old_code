-- file: ch03/Direction.hs

data Direction = ToLeft | ToRigth | Straight
data Point a = Point a a

-- turnOfPoints :: (Num a, Eq a) => Point a -> Point a -> Point a -> Direction
-- turnOfPoints (Point a a') (Point b b') (Point c c')
--     | 
--    where m = (a'-b') / (a-b)
--          y x = m*(x-a) + a'