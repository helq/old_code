-- file: ch06/naiveeq.hs

import Data.Char (isSpace)

data Color = Red | Green | Blue
    deriving (Show)

instance Read Color where
    readsPrec _ v = 
        tryParse [("Red", Red), ("Green", Green), ("Blue", Blue)]
            where tryParse [] = []
                  tryParse ((attempt, result):xs)
                      | attempt' == attempt = [(result, remain)]
                      | otherwise           = tryParse xs
                          where
                            (attempt',remain) = splitAtWhit attempt value

                            splitAtWhit :: [t] -> [a] -> ([a],[a])
                            splitAtWhit _       []    = ([],[])
                            splitAtWhit []      ys    = ([],ys)
                            splitAtWhit (x:xs) (y:ys) = (y:ys',ys'')
                                where (ys',ys'') = splitAtWhit xs ys

                  value = dropWhile isSpace v

