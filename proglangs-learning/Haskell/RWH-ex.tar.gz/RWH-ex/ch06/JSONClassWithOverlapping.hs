{-# LANGUAGE TypeSynonymInstances, FlexibleInstances, OverlappingInstances #-}

module JSONClass where

--import qualified SimpleJSON as SJSON
import SimpleJSON
import PutJSON (renderJValue)

--newtype JValue = JValue (SJSON.JValue) deriving (Eq, Ord)

type JSONError = String

class JSON a where
    toJValue :: a -> JValue
    fromJValue :: JValue -> Either JSONError a

instance JSON JValue where
    toJValue = id
    fromJValue = Right

-- Bool
instance JSON Bool where
    toJValue = JBool

    fromJValue (JBool b) = Right b
    fromJValue _ = Left "no a JSON boolean"

-- String
instance JSON String where
    toJValue = JString

    fromJValue (JString s) = Right s
    fromJValue _ = Left "not a JSON string"

-- Numbers
jValueToNum :: (Double -> a) -> JValue -> Either JSONError a
jValueToNum f (JNumber v) = Right (f v)
jValueToNum _ _ = Left "not a JSON number"

instance JSON Int where
    toJValue = JNumber . realToFrac
    fromJValue = jValueToNum round

instance JSON Integer where
    toJValue = JNumber . realToFrac
    fromJValue = jValueToNum round

instance JSON Double where
    toJValue = JNumber
    fromJValue = jValueToNum id

fromRight (Right b) = b

-- Array
instance (JSON a) => JSON [a] where
    toJValue = JArray . map toJValue

    -- bogus
    fromJValue (JArray xs) = Right $ map (fromRight.fromJValue) xs
    fromJValue _ = Left "not a JSON Array"

-- Objects
instance (JSON a) => JSON [(String, a)] where
    toJValue = JObject . map (\(x,y)->(x,toJValue y))

    -- bogus
    fromJValue (JObject xs) = Right $ map (\(x,y)->(x, fromRight.fromJValue $ y)) xs
    fromJValue _ = Left "not a JSON Object"
