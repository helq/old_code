-- file: ch06/SimpleClass.hs
-- This trick is used in Show
import Data.List

class Foo a where
    foo :: a -> String
    
    fooList :: Foo a => [a] -> String
    fooList = concat . intersperse ", " . map foo

instance Foo a => Foo [a] where
    foo = fooList

instance Foo Char where
    foo c = [c]
    fooList = id

instance Foo Int where
    foo = show

-- try:
--   foo [1,5,56,6::Int]
--   foo "string XD"
