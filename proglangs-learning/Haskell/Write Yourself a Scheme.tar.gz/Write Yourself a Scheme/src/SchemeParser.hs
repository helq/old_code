module SchemeParser (readExpr) where

import Text.ParserCombinators.Parsec hiding (spaces)
import Data.Array (Array(..), listArray, bounds)
import Data.Traversable hiding (sequenceA)
import Data.Monoid

data LispVal = Atom String
             | List [LispVal]
             | Array (Array Int LispVal)
             | DottedList [LispVal] LispVal
             | Number Integer
             | String String
             | Bool Bool
             deriving (Show)

{-
 -sequenceA :: (Traversable t, Applicative f) => t (f a) -> f (t a)
 -sequenceA = traverse id
 -
 -foldMap' :: Monoid m => (a -> m) -> [a] -> m
 -foldMap' f = foldr ((<>).f) mempty
 -
 -foldMap'' :: Monoid m => (a -> m) -> [a] -> m
 -foldMap'' f = helper
 -    where
 -        helper (x:xs) = f x <> helper xs
 -        helper []     = mempty
 -}

symbol :: Parser Char
symbol = oneOf "!#$%&|*+-/:<=>?@^_~"

spaces :: Parser ()
spaces = skipMany1 space

parseString :: Parser LispVal
parseString = do
                char '"'
                x <- many $ noneOf "\\\"" <|> escapedChar
                char '"'
                return $ String x
    where
    escapedChar :: Parser Char
    escapedChar = do
                char '\\'
                escapedChar <- oneOf "nrt\\\"'"
                return $ case escapedChar of
                            'n' -> '\n'
                            'r' -> '\r'
                            't' -> '\t'
                            _   -> escapedChar

parseAtom :: Parser LispVal
parseAtom = do
              first <- letter <|> symbol
              rest  <- many (letter <|> digit <|> symbol)
              let atom = first:rest
              return $ case atom of
                         "#t" -> Bool True
                         "#f" -> Bool False
                         _    -> Atom atom

parseNumber :: Parser LispVal
parseNumber = (Number . read) <$> many1 digit

parseExpr :: Parser LispVal
parseExpr =  parseArray
         <|> parseAtom
         <|> parseString
         <|> parseNumber
         <|> parseQuoted
         <|> parseQuasiQuoted
         <|> do char '('
                aList <- try parseList <|> parseDottedList
                char ')'
                return aList

parseList :: Parser LispVal
parseList = List <$> sepBy parseExpr spaces

parseDottedList :: Parser LispVal
parseDottedList = do
    head <- endBy parseExpr spaces
    tail <- char '.' >> spaces >> parseExpr
    return $ DottedList head tail

parseQuoted :: Parser LispVal
parseQuoted = do
    char '\''
    x <- parseExpr
    return $ List [Atom "quote", x]

parseArray :: Parser LispVal
parseArray = do
    char '#' >> char '('
    List xs <- try parseList
    char ')'
    let len = length xs
    return . Array $ listArray (0, len - 1) xs

parseQuasiQuoted :: Parser LispVal
parseQuasiQuoted = do
    char '`'
    x <- parseExpr
    return $ List [Atom "quasiquote", x]

readExpr :: String -> String
readExpr input = case parse parseExpr "lisp" input of
    Left err  -> "No match: " ++ show err
    Right val -> "Found value : " ++ show val
