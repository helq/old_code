#include <stdio.h>

#define ASCII_VALUES 0x7f
#define LENGTH_CONSOLA 100

void putLines(int i, int chars[]) {
   int j;
   for (j=0; j<chars[i]; j++)
      putchar('-');
}

int main()
{
   int c, totalChars;
   int chars[ASCII_VALUES];

   int i;
   for (i=0; i<ASCII_VALUES; i++ )
      chars[i]=0;

   totalChars = 0;
   while ( (c=getchar())!=EOF ){
      chars[c]++;
      totalChars++;
   }

   for (i=0; i<ASCII_VALUES; i++ )
      chars[i]=(chars[i]*LENGTH_CONSOLA)/totalChars;

   printf("\n \\n "); putLines('\n', chars);
   printf("\n \\t "); putLines('\t', chars);
   printf("\n' ' ");  putLines(' ', chars);

   for (i='!'; i<='~'; i++){
      printf("\n%2c ", i);
      putLines(i, chars);
   }
   printf("\n");

   return 0;
}
