#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLEN 1000 /* max length of any input line */
int getline(char[], int);

/* readlines: read input lines */
int readlines(char *lineptr[], int maxlines)
{
   int len, nlines;
   char *p, line[MAXLEN];
   
   nlines = 0;
   while ((len = getline(line, MAXLEN)) > 0)
      if (nlines >= maxlines || (p = malloc(len*sizeof(char))) == NULL)
         return -1;
      else {
         line[len-1] = '\0';  /* Delete newline */
         strcpy(p, line);
         lineptr[nlines++] = p;
      }
   return nlines;
}

/* writelines: write output lines */
void writelines(char *lineptr[], int nlines)
{
   int i;
   
   for (i=0; i<nlines; i++)
      printf("%s\n", lineptr[i]);
}

/* getline: read a line into s, return length */
int getline(char s[], int lim)
{
   int c, i;

   for ( i=0; i < lim-1 && (c=getchar())!=EOF && c!='\n'; i++ )
      s[i] = c;
   if (c=='\n') s[i++] = '\n';
   s[i] = '\0';

   return i;
}
