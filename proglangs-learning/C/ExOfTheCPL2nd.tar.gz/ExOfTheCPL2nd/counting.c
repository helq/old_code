#include <stdio.h>

int main()
{
   int c;
   long nc = 0; /*Number of characters*/
   long nl = 0; /*Number of new-line*/
   long nt = 0; /*Number of tab*/
   long ns = 0; /*Number of spaces*/

   for ( ; (c=getchar()) != EOF; ++nc)
      if      (c==' ')  ns++;
      else if (c=='\t') nt++;
      else if (c=='\n') nl++;

   printf("Number of characters: %6ld\n", nc);
   printf("Number of new-line:   %6ld\n", nl);
   printf("Number of tab:        %6ld\n", nt);
   printf("Number of spaces:     %6ld\n", ns);

   return 0;
}