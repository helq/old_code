#include <stdio.h>

#define TABSTOP 8

void printTabs( int spaces, int stop );

int main()
{
   int c,       /* current character */
       col,     /* current column */
       spaces = 0,
       stop = 0;  /* Length to final tabStop */

   col = 0;
   while ( (c=getchar()) != EOF )
   {
      if( c == ' ' )
         spaces++;
      else if ( c == '\t' ){
         spaces += TABSTOP - col%TABSTOP;
         col += TABSTOP - col%TABSTOP - 1 ;
      }
      else{
         printTabs(spaces, stop);
         spaces = 0;
         stop = (col+1)%TABSTOP;
         putchar(c);
      }

      col++;

      if( c == '\n' )
         col = stop = 0;
   }

   return 0;
}

void printTabs( int spaces, int stop ){
   int tabs;

   if(spaces == 1){
      putchar(' ');
      return;
   }

   int i;
   if( spaces+stop>7 )
      spaces+=stop;

   tabs = spaces/TABSTOP;
   for ( i=0; i<tabs; i++ )
      putchar('\t');

   spaces %= TABSTOP;
   for ( i=0; i<spaces; i++ )
      putchar(' ');
}
