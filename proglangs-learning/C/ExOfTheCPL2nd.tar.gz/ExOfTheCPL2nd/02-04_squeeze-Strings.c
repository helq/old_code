#include <stdio.h>

int charInString(char s[], char c) {
   int i=-1;
   while( s[++i]!=c && s[i]!='\0' );
   return s[i] ? 1 : 0;
}
/* squeeze: delete all characters from s2 in s1 */
void squeeze(char s1[], char s2[])
{
   int i, j;

   for(i=j=0; s1[i]!='\0'; i++)
      if( ! charInString(s2, s1[i]) )
        s1[j++] = s1[i];
   s1[j] = '\0';
}

int main()
{
   char a[] = "Hello World!";
   char b[] = "!el";

   squeeze(a, b);
   printf("%s\n", a);

   return 0;
}
