#include <stdio.h>

#define LEN_MIN 80        /* Max length that not print */
#define MAXLINE LEN_MIN+2 /*Maximum input line length*/

int getLine(char line[], int maxLine);

/* print the input lines that are longer than 80 */
int main()
{
   int len;               /* current line length */
   char line[MAXLINE];    /* current input line */
   int status = OUT;

   while ( (len=getLine(line, MAXLINE)) > 0 )
      if (status==IN){
         if(len<MAXLINE-1 || line[MAXLINE-2]=='\n')
            status=OUT;
         printf("%s", line);
      }
      else if (len>LEN_MIN){
         printf("%s", line);
         if(len==MAXLINE-1 && line[MAXLINE-2]!='\n')
            status = IN;
      }

   return 0;
}

/* getLine: read a line into s, return length */
int getLine(char s[], int lim)
{
   int c, i;

   for ( i=0; i < lim-1 && (c=getchar())!=EOF && c!='\n'; i++ )
      s[i] = c;
   if (c=='\n') s[i++] = '\n';
   s[i] = '\0';

   return i;
}
