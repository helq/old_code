#include <stdio.h>

#define IN  0 /* inside a word */
#define OUT 1 /* outside a word */
#define MAX_LENGTH_WORDS 20 /*Defining the max length of one word*/

int main()
{
   int c, state = OUT, stateN = 0;
   int lenWords[MAX_LENGTH_WORDS];

   int i;
   for (i=0; i<MAX_LENGTH_WORDS; i++ )
      lenWords[i]=0;

   while ( (c=getchar())!=EOF )
   {
      if ( c==' ' || c=='\n' || c=='\t' ) {
         if (state==IN){
            lenWords[stateN-1]++;
            stateN = 0;
         }
         state = OUT;
      }
      else {
         state = IN;
         stateN++;
      }
   }

   printf("Length of Words\n");
   for (i=0; i<MAX_LENGTH_WORDS; i++)
      printf(" %2d", i+1);

   putchar('\n');
   int k=1, line=1;
   while (k>0){
      k=0;
      for (i=0; i<MAX_LENGTH_WORDS; i++){
         if ( lenWords[i]-line >= 0 ){
            printf("  |");
            k++;
         }
         else
            printf("   ");
      }
      line++;
      putchar('\n');
   }

   return 0;
}
