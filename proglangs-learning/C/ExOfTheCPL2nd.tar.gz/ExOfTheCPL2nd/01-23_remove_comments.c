#include <stdio.h>

#define IN  1 /* in a comment */
#define OUT 0 /* out a comment */
#define INSTR  1 /* in a string */
#define OUTSTR 0 /* in a string */

int main()
{
   int c, state = OUT, str = OUTSTR, chr = OUTSTR;

   while ( (c=getchar()) != EOF )
   {
      if(state==OUT){
         if( c == '/' && str == OUTSTR )
            if( (c=getchar()) =='*' ) /* Comment of type *asterisk* */
               state=IN;
            else if( c == '/' ) /* Comment of type // */ {
               while( (c=getchar()) != '\n' );
               putchar('\n');
            }
            else printf("/%c", c);
         else putchar(c);

         /* Restrictions */
         if( c == '"' )
            str = str==OUTSTR ? INSTR : OUTSTR;
         else if ( c == '\'' ){
            chr = chr==OUTSTR ? INSTR : OUTSTR;
            if (chr==INSTR)
               putchar(getchar());
         }
      }
      else
         if( c == '*' )
            if( (c=getchar()) == '/' )
               state = OUT;
   }
   
   return 0;
}
