#include <stdio.h>

#define yesno(a) (a ? "yes" : "no")
#define yesprint(a) printf("%s\n", yesno(a))

void mystrcat(char *s, char *t);
int strend(char *s, char *t);

int main()
{
   char p[6] = "one-", q[] = "two";
   mystrcat(p, q);
   printf("%s\n", p);
   
   yesprint(strend(p, q));
   yesprint(strend(p, "wwo"));
   
   return 0;
}

void mystrcat(char *s, char *t)
{
   while (*s != '\0')
      s++;
   while ((*s++ = *t++) != '\0')
      ;
}

int strend(char *s, char *t)
{
   char *i = s, *j = t;
   
   while (*s != '\0')
      s++;
   while (*t != '\0')
      t++;
   
   while ( *s == *t && i <= s && j <= t )
      s--, t--;
   
   return j-1 == t;
}
