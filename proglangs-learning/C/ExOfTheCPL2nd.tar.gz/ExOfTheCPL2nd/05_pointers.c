#include <stdio.h>
#include <stdlib.h>

#define dprint(expr, type) printf(#expr "\t= %" type "\n", expr)

int main()
{
   int i = 25;
   int *ip;
   
   dprint(i, "d");
   dprint(&i, "p");
   
   ip = &i;
   
   dprint(*ip, "d");
   dprint(ip, "p");
   dprint(ip + 1, "p");
   
   ip = malloc(4);
   dprint(ip, "p");
   ip[0] = 15; ip[4] = 150;
   ip = realloc(ip, 6);
   dprint(ip, "p");
   
   dprint(ip[0], "d");
   dprint(ip[4], "d");
   
   
   int a=10, *b=&a, **c=&b/*, ***d=&c*/;
   *b*=**c;
   printf("%d\n", a);
   
   int r[] = {1,2,3,2,3,6};
   printf("%lu\n", sizeof(r));
   
   return 0;
}
