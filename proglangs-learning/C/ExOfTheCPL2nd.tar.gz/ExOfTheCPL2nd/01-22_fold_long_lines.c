#include <stdio.h>

#define MAXLINE 80
#define TABSTOP 8
#define IN 1
#define OUT 0

int main()
{
   int i;
   int c, lenLine=0, /*col=0, */finSpace=MAXLINE, status=OUT;
   char line[MAXLINE+1], cTmp;

   while( (c=getchar()) != EOF )
   {
      /* Delete initial spaces if is in the same paragraph of the above */
      if ( !(status==IN && lenLine==0 && c==' ') )
         line[lenLine++]=c;

      if ( c==' ' )
         finSpace = lenLine;

      if( c=='\n' )
      {
         line[lenLine]='\0';
         printf("%s", line);
         lenLine=0;
         finSpace = MAXLINE;
         status = OUT;
      }
      else if ( lenLine == MAXLINE )
      {
         cTmp = line[finSpace];

         line[finSpace]='\0';
         printf("%s", line);
         putchar('\n');

         lenLine = MAXLINE - finSpace;

         line[finSpace] = cTmp;
         for(i=0; i<lenLine; i++)
            line[i] = line[finSpace+i];

         finSpace = MAXLINE;
         status = IN;
      }
   }

   line[lenLine]='\0';
   printf("%s", line);

   return 0;
}
