#include <stdio.h>

#define swap(t, a, b) { register t tmp = a; a = b; b = tmp; }
#define dprint(expr, type) printf(#expr " = %" type "\n", expr)

int main()
{
   int i = 20,
       j = 6,
       tmp = 8;
   
   swap(int, i, j);
   
   dprint(i, "d");
   dprint(j, "d");
   dprint(tmp, "d");
   
   return 0;
}
