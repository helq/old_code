#include <stdio.h>
#include <ctype.h>

/* Convert String that represent a number in hexadecimal to Integer */
int htoi(char s[]){
   int i, n, c;
   
   if(tolower(s[1])!='x') i=0;
   else i=2;
   
   for(n=0; (c=tolower(s[i])); i++)
      if (c>='0' && c<='9')
         n = (n<<4) + s[i] - '0';
      else if (c>='a' && c<='f')
         n = (n<<4) + s[i] - 'a' + 10;
      else break;
   
   return n;
}


int main()
{
   printf("%X\n", htoi("0x1234bcf"));
   
   return 0;
}
