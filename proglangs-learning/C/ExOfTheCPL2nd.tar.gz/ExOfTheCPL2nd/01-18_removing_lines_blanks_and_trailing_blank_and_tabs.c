#include <stdio.h>

#define MAXLINE 1000 /*Maximum input line length*/ + 1

int getLine(char line[], int maxLine);
int clearBlanks(char line[], int length);

/* print the input lines that are longer than 80 */
int main()
{
   int len;               /* current line length */
   char line[MAXLINE];    /* current input line */

   while ( (len=getLine(line, MAXLINE)) > 0 ){
      len = clearBlanks(line, len);
      if(len > 1)
         printf(line);
   }

   return 0;
}

/* getLine: read a line into s, return length */
int getLine(char s[], int lim)
{
   int c, i;

   for ( i=0; i < lim-1 && (c=getchar())!=EOF && c!='\n'; i++ )
      s[i] = c;
   if (c=='\n') s[i++] = '\n';
   s[i] = '\0';

   return i;
}

/* return new length of line */
int clearBlanks(char s[], int len)
{
   if(s[--len]=='\n'){
      while((s[--len]==' ' || s[len]=='\t') && len>=0 );
      s[++len]='\n';
      s[++len]='\0';
   } else
      len++;
   return len;
}