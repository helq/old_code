#include <stdio.h>

unsigned rightrot(unsigned x, int n) {
   int i = sizeof(x)*8;
   n %= i;
   return (x >> n) | (x << (i-n));
}

int main()
{
   printf("%#x\n", rightrot(0x1234, 8));
   
   return 0;
}
