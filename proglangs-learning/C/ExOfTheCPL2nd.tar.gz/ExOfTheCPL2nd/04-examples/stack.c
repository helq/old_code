#include <stdio.h>
#include "calc.h"

#define MAXVAL  100 /* maximum depth of val stack */

static int sp = 0;         /* next free stack */
static double val[MAXVAL]; /* value stack */

/* push: push f onto value stack */
void push(double f)
{
   if (sp < MAXVAL)
      val[sp++] = f;
   else
      printf("error: stack full, can't push %g\n", f);
}

/* pop: pop and return top value from stack */
double pop()
{
   if (sp>0)
      return val[--sp];
   else {
      printf("error: stack empty\n");
      return 0.0;
   }
}

/* get: get and return top value from stack */
double get()
{
   if (sp>0)
      return val[sp-1];
   else {
      printf("error: stack empty\n");
      return 0.0;
   }
}

/* printStack: print stack */
void printStack()
{
   int i;
   printf("[");
   for(i=0; i<sp-1; printf("%.8g, ", val[i++]))
      ;
   if (i==sp-1)
      printf("%.8g", val[i]);
   printf("]\n");
}

/* clearS: clear from stack */
void clearS() {
   sp = 0;
}

/* swapS: swap two top elmements from stack */
void swapS()
{
   if (sp < 2) return;
   int tmp;
   tmp = val[sp-1];
   val[sp-1] = val[sp-2];
   val[sp-2] = tmp;
}

/* duplicate: duplicate top element onto value stack */
void duplicate()
{
   if (sp < MAXVAL) {
      val[sp] = val[sp-1];
      sp++;
   }
   else
      printf("error: stack full, can't duplicate %g\n", val[sp-1]);
}

