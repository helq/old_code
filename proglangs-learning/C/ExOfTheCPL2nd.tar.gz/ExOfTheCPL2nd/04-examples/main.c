#include <stdio.h>
#include <stdlib.h> /* for atof() */
#include <ctype.h>
#include "calc.h"

#define MAXOP  100 /* max size of operand or operator */

/* reverse Polish calculator */
int main()
{
   int type, vp;
   double op2, last, var['z'-'a'+1];
   char s[MAXOP];
   
   while ((type = getop(s)) != EOF) {
      if (type == '#') {
         if ( islower(type = getchar()) ) {
            vp = type - 'a';
            var[vp] = last;
            type = ' ';
         }
         push(last);
      }
      if (islower(type)) {
         vp = type - 'a';
         type = ' ';
         push(var[vp]);
      }
      switch (type) {
         case NUMBER:
            push(atof(s));
            break;
         case ' ':
            break;
         case '+':
            push(pop() + pop());
            break;
         case '*':
            push(pop() * pop());
            break;
         case '-':
            op2 = pop();
            push(pop() - op2);
            break;
         case '/':
            op2 = pop();
            if (op2 != 0.0)
               push(pop() / op2);
            else
               printf("error: zero divisor\n");
            break;
         case '%':
            op2 = pop();
            if (op2 != 0.0)
               push((int)pop() % (int)op2);
            else
               printf("error: zero divisor\n");
            break;
         case '\n':
            printf("\t%.8g\n", last = pop());
            break;
         default:
            printf("error: unknown comand %s\n", s);
            break;
      }
   }
   
   return 0;
}
