#define NUMBER '0' /* sign that a number was found */

void push(double);
double pop();
int getop(char []);
int getch();
void ungetch();

