#include <stdio.h>

char lower(char x){
   return (x>='A' && x<='Z') ? x-'A'+'a' : x;
}

int main(){
   printf("%cello World!\n", lower('H'));
   return 0;
}
