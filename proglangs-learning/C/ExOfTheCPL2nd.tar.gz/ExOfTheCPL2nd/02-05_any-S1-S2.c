#include <stdio.h>

int charInString(char s[], char c) {
   int i=-1;
   while( s[++i]!=c && s[i]!='\0' );
   return s[i] ? 1 : 0;
}
int any(char s1[], char s2[]) {
   int i;
   for(i=0; s1[i]!='\0' && !charInString(s2, s1[i]); i++);
   
   return s1[i]!='\0' ? i : -1 ;
}

int main()
{
   char a[] = "Hello World";
   char b[] = "Hello World";
   
   printf("%i\n", any(a, "bwxlk"));
   printf("%i\n", any(b, "z"));
   
   return 0;
}
