#include <stdio.h>

#define MAXLINE 80 + 1 /* Maximum input line length */
#define IN 1
#define OUT 0

int getLine(char line[], int maxLine);
void copy(char to[], char from[]);

/*print the longest input line*/
int main()
{
   int len;               /* current line length */
   int max;               /* maximum length seen so far */
   char line[MAXLINE];    /* current input line */
   char longest[MAXLINE]; /* longest line saved here */
   int status = OUT;
   int maxT;

   max = 0;
   while ( (len=getLine(line, MAXLINE)) > 0 )
   {
      if (len>max) {
         max = len;
         copy(longest, line);
      }
      if (status == IN) {
         if(len<MAXLINE-1 || line[MAXLINE-2]=='\n' )
            status=OUT;
         maxT += len;
         if (maxT>max)
            max = maxT;
      }
      if (len==MAXLINE-1 && line[MAXLINE-2]!='\n' && status==OUT){
         status = IN;
         maxT = len;
      }
   }

   if (max > 0) { /* there was a line */
      printf("Size of longest line: %d \n", max);
      printf("Possible longest line:\n%s", longest);
   }

   return 0;
}

/* getLine: read a line into s, return length */
int getLine(char s[], int lim)
{
   int c, i;

   for ( i=0; i < lim-1 && (c=getchar())!=EOF && c!='\n'; i++ )
      s[i] = c;
   if (c=='\n') s[i++] = '\n';
   s[i] = '\0';

   return i;
}

/* copy: copy 'from' into 'to'; asume to is big enough */
void copy(char to[], char from[])
{
   int i;

   i = 0;
   while ( (to[i]=from[i]) != '\0' )
      i++;
}
