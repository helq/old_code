#include <stdio.h>

#define LEN_STACK 100

 /* Check a C program for rudimentary syntax errors brackets,
  * braces, parentheses, single quote and double quote.
 */

int push(char a);
int pop();
int peek();
void inconsistely(char str[], int line, int col);

char stack[LEN_STACK];
int head=-1;

int main()
{
   int c, col=0, line=1, c_old;

   while( (c=getchar()) != EOF )
   {
      col++;

      /* Double Quotes */
      if(c=='"'){
         col++;
         while( (c=getchar()) != '"' && c != EOF )
         {
            if      ( c=='\\' ) { getchar(); col++; }
            else if ( c == '\n' ){
               inconsistely("double quotes", line, col);
               break;
            }
            col++;
         }
         col++;
      }

      /* Single Quotes */
      if(c=='\''){
         if( (c=getchar()) == '\\' ) { c=getchar(); col++; }
         if( c=='\n' || (c=getchar()) != '\'' )
            inconsistely("single quotes", line, col);
         col+=2;
      } 

      /* Comments *asterisk* */
      if( c=='/' && (c=getchar())=='*' ) {
         col+=2;
         c_old=c;
         while( (c=getchar())!='/' || c_old!='*' ){
            if(c=='\n') { col=0; line++; }
            else col++;
            c_old=c;
         }
      } 

      /* Parentheses, Brackets and Braces */
      if( c=='(' || c=='[' || c=='{' ){
         if( push(c) ){
            printf(" OVER STACK :S :%d:%d\n", line, col);
            return -1;
         }
      }else if( c==')' ){
         if(peek()=='(') pop();
         else inconsistely("parentheses", line, col);
      }else if( c==']' ){
         if(peek()=='[') pop();
         else inconsistely("brackets", line, col);
      }else if( c=='}' ){
         if(peek()=='{') pop();
         else inconsistely("braces", line, col);
      }

      if(c=='\n'){
         col = 0;
         line++;
      }
   }

   if(peek()!=-1)
      printf("Stack non-empty, Inconsistently :S\n");

   return 0;
}

int push(char a) {
   if( head+1 >= LEN_STACK ) return -1;

   stack[++head] = a;
   return 0;
}

int pop(){
   if( head<0 ) return -1;
   return stack[head--];
}

int peek(){
   if( head<0 ) return -1;
   return stack[head];
}

void inconsistely(char str[], int line, int col) {
   printf("Inconsistently %s close:%d:%d\n", str, line, col);
}