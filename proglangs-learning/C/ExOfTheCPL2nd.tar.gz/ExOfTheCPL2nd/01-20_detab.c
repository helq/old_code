#include <stdio.h>

#define TABSTOP 8

int main()
{
   int c,       /* current character */
       col,     /* current column */
       spaces;  /* Number of spaces to add */
   int i;

   col = 0;
   while ( (c=getchar()) != EOF )
   {
      if( c == '\t' ){
         spaces = TABSTOP - col%TABSTOP;
         for( i=0;  i<spaces; i++ )
            putchar(' ');
         col += spaces-1;
      }
      else
         putchar(c);

      col++;
      if( c == '\n' ) col = 0;
   }

   return 0;
}
