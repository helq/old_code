#include <stdio.h>

int main()
{
   int i;

   char size=1;
   for(i=1; size<<=1; i++);
   printf("char      %2d : %hhu\n", i, (char)-1);

   short int size1=1;
   for(i=1; size1<<=1; i++);
   printf("short     %2d : %hu\n", i, (short)-1);

   int size2=1;
   for(i=1; size2<<=1; i++);
   printf("int       %2d : %u\n", i, (int)-1);

   long int size3=1;
   for(i=1; size3<<=1; i++);
   printf("long      %2d : %lu\n", i, (long)-1);

   long long int size4=1;
   for(i=1; size4<<=1; i++);
   printf("long long %2d : %llu\n", i, (long long)-1);

   return 0;
}
