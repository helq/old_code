#include <stdio.h>

int myStrlen(char s[]){
   int i;
   for(i=0; s[i]!='\0'; i++) ;
   return i;
}

/* reverse: reverse string in the place */
void reverse(char s[]) {
   int c, i, j;
   for(i=0, j=myStrlen(s)-1; i<j; i++, j--)
      c = s[i], s[i] = s[j], s[j] = c;
}

/* itoa: convert n to characters in s */
void itoa(int n, char s[], int w)
{
   int i=0, sign;

   if( (sign=n) < 0 )
      s[i++] = -(n%10)+'0', n /= 10, n = -n;
   
   do s[i++] = n % 10 + '0';
   while( (n /= 10) > 0 );
   if (sign < 0)
      s[i++] = '-';

   for(; i<w; i++) s[i] = ' ';

   s[i] ='\0';
   reverse(s);
}

int main()
{
   char s[10];
   
   itoa(1256, s, 6);
   printf( s );
   printf("\n");

   return 0;
}
