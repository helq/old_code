#include <stdio.h>

unsigned invert(unsigned x, int p, int n) {
   return ((~(~0 << n)) << (p-n+1)) ^ x;
}

int main()
{
   printf("%#x\n", invert(0x123459, 7, 8)); /* 0x1234a6 */
   
   return 0;
}
