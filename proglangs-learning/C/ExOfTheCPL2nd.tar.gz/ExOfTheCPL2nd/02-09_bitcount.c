#include <stdio.h>

/* bitcount: count 1 bits in x */
int bitcount(int x){
   int b;
   for(b=0; x!=0; x&=(x-1), b++);
   return b;
}


int main()
{
   int k = -1;
   printf("The number %#x have %d bits 1\n", k, bitcount(k));
   k = 0x123456ab;
   printf("The number %#x have %d bits 1\n", k, bitcount(k));
   
   return 0;
}
