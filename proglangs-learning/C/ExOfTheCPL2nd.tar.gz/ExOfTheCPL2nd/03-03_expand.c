#include <stdio.h>
#include <ctype.h>

int theExpand(char a, char b, char s2[], int i)
{
   int j;
   for(j = a; j<=b; j++, i++)
      s2[i] = j;
   return i;
}

void expand(char s1[], char s2[])
{
   int i, j;
   char ini, fin;

   if(s1[0]=='-')
      i = j = 1, s2[0] = '-';
   else
      i = j = 0;
   
   for(ini = fin = '\0'; s1[i]!='\0'; i++ )
   {
      if( isalnum(s1[i]) )
         if( ini == '\0' )
            ini = s1[i];
         else if(fin == '\0')
            fin = s1[i];
         else
            ini = s1[i], fin = '\0';
      else if(s1[i] == '-') {
         if(fin != '\0')
            ini = fin, fin = '\0';
      }
      else
         s2[j++] = s1[i], ini = fin = '\0';
      
      if( ini !='\0' && fin != '\0' )
         j = theExpand(ini, fin, s2, j);
   }
   
   if(fin == '\0')
      s2[j++] = '-';
   
   s2[j] = '\0';
}

int main()
{
   char a[60];

   expand("a-z", a);
   printf("%s\n", a);
   
   expand("-a-zA-Z", a);
   printf("%s\n", a);
   
   expand("@#a-m-z# 0-8", a);
   printf("%s\n", a);
   
   return 0;
}

