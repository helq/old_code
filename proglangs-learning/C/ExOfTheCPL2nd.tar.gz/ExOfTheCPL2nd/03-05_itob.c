#include <stdio.h>

int myStrlen(char s[]){
   int i;
   for(i=0; s[i]!='\0'; i++) ;
   return i;
}

/* reverse: reverse string in the place */
void reverse(char s[]) {
   int c, i, j;
   for(i=0, j=myStrlen(s)-1; i<j; i++, j--)
      c = s[i], s[i] = s[j], s[j] = c;
}

char itoc(int a) {
   return 0<=a && a<=9 ? a + '0' : ( a<36 ? a-10+'a' : '#' );
}

/* itob: convert n to characters in s */
void itob(int n, char s[], int b)
{
   int i=0, sign;

   if( (sign=n) < 0 )
      s[i++] = itoc(-(n%b)), n /= b, n = -n;
   
   do s[i++] = itoc(n % b);
   while( (n /= b) > 0 );
   if (sign < 0)
      s[i++] = '-';
   s[i] ='\0';
   reverse(s);
}

int main()
{
   char a[10];
   
   itob(0x83a4f, a, 16);
   printf("%s\n", a);
   
   itob(71, a, 36);
   printf("%s\n", a);
   
   return 0;
}
