#include <stdio.h>

/* getbits: get n bits from position p */
unsigned getbits(unsigned x, int p, int n) {
   return (x >> (p-n+1)) & ~(~0 << n);
}

/* setbits: set n bits from position p, of rightmost n bits of y */
unsigned setbits(unsigned x, int p, int n, unsigned int y){
   int k = p+1-n;
   return ( (x & ~((~(~0 << n)) << k))
          | ((y & ~(~0 << n)) << k));
}


int main()
{
   printf("%#x\n", getbits(0x12345, 15, 16)); /* 0x2345 */
   printf("%#x\n", setbits(0x12345, 7, 8, 0xcab)); /* 0x123ab */
   
   return 0;
}

