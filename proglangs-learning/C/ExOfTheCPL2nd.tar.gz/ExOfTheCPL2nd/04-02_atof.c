#include <stdio.h>
#include <ctype.h>

/* atof: convert string s to double */
double atof(char s[])
{
   double val;
   int i, sign, ePower, power, power2;
   
   for (i=0; isspace(s[i]); i++) /* skip white space */
      ;
   sign = (s[i] == '-') ? -1 : 1;
   if (s[i] == '+' || s[i] == '-')
      i++;
   for (val = 0.0; isdigit(s[i]); i++)
      val = 10.0 * val + (s[i] - '0');
   if (s[i] == '.')
      i++;
   for (power = 0; isdigit(s[i]); i++) {
      val = 10.0 * val + (s[i] - '0');
      power += 1;
   }
   
   if (s[i] == 'e' || s[i] == 'E') {
      i++;
      ePower = (s[i] == '-') ? -1 : 1;
      if (s[i] == '+' || s[i] == '-')
         i++;
      for (power2 = 0; isdigit(s[i]); i++)
         power2 = 10*power2 + (s[i] - '0');
      power -= power2*ePower;
   }
   
   if (power > 0)
      for(val*=sign; power > 0; power--)
         val /= 10;
   else
      for(val*=sign; power < 0; power++)
         val *= 10;

   return val;
}


int main()
{
   printf("%e\n", atof("  +1234.25e-11"));
   
   return 0;
}

