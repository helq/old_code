numero = int(raw_input('Dame un n�mero: '))

print '%d elevado a %d es %d' % (numero, 2, numero ** 2) 
print '%d elevado a %d es %d' % (numero, 3, numero ** 3) 
print '%d elevado a %d es %d' % (numero, 4, numero ** 4) 
print '%d elevado a %d es %d' % (numero, 5, numero ** 5) 
