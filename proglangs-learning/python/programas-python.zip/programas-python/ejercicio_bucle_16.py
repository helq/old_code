i = int(raw_input('Valor inicial: '))
limite = int(raw_input('L�mite: '))
incremento = int(raw_input('Incremento: '))
while i < limite:
  print i
  i += incremento
