a = [1, 2, -1, -4, 5, -2]

for i in a:
  if i < 0:
    del i

print a
