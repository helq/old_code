print '�Hola, mundo!'
