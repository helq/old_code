def cuadrado(x):
  return x ** 2

print cuadrado(2)
