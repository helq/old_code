print '�Hola,', 'mundo!'
