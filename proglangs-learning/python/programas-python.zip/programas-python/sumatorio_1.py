sumatorio = 0
i = 1
while i <= 1000:
  sumatorio += i
  i += 1
print sumatorio
