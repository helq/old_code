for i in range(0, 4):
  for j in range(0, 4):
    for k in range(0, 2):
      print i, j, k
