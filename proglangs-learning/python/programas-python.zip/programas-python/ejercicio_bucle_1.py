i = 0
while i <= 3:
  print i
  i += 1
print 'Hecho'
