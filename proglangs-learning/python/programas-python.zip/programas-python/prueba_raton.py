while 1:
  [boton, x, y] = mouse_state()
  print boton, x, y
  if boton == 3: 
    break
