def es_mayor_de_edad(edad):
  if edad < 18:
    return False
  else:
    return True
