i = 10
while i < 2:
  i *= 2
  print i
