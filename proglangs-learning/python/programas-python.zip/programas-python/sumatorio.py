sumatorio = 0
for i in range(1, 1001):
  sumatorio += i

print sumatorio
