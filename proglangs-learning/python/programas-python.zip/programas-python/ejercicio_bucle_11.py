i = 3
while i < 10:
  i += 2
  print i
print 'Hecho'
