from math import pi, sin

window_size (500, 500) 
window_coordinates(-2*pi, -1.5, 2*pi, 1.5)

create_point(-2*pi, sin(-2*pi))
create_point(-1.5*pi, sin(-1.5*pi))
create_point(-pi, sin(-pi))
create_point(-0.5*pi, sin(-0.5*pi))
create_point(0, sin(0))
create_point(0.5*pi, sin(0.5*pi))
create_point(pi, sin(pi))
create_point(1.5*pi, sin(1.5*pi))
create_point(2*pi, sin(2*pi))
