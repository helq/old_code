def incrementa(p):
  p = p + 1
  return p

a = 1
a = incrementa(2+2)
print 'a:', a
