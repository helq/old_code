a = float(raw_input('Valor de a: '))
b = float(raw_input('Valor de b: '))

if a != 0:
  x = -b/a
  print 'Soluci�n: ', x 

print 'La ecuaci�n no tiene soluci�n.'  
