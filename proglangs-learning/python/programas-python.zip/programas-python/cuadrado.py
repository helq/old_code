def cuadrado(x):
  return x ** 2

print cuadrado(2)
a = 1 + cuadrado(3)
print cuadrado(a * 3)
