from math import pi

radio = float(raw_input('Dame el radio: '))
area = pi*radio**2

print 'El �rea de un c�rculo de radio %f es %f' % (radio, area) 
print 'El �rea de un c�rculo de radio %6.3f es %6.3f' % (radio, area) 
