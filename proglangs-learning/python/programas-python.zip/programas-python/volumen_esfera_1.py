from math import pi

radio = 1
volumen = 4.0 / 3.0 * pi * radio ** 3

print volumen
