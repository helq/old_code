for i in range(0, 5):
  for j in range(0, 3):
    print i, j
