a = int(raw_input('Dame el primer n�mero: '))
b = int(raw_input('Dame el segundo n�mero: '))

if a > b:
  maximo = a
else:
  maximo = b

print 'El m�ximo es', maximo
