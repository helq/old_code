if 14 < 120:
  print 'Primer saludo'
if '14' < '120':
  print 'Segundo saludo'
