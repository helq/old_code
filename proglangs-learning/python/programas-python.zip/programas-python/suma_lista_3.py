def sumatorio(lista):
  s = 0
  for numero in lista:
    s += numero
  return numero

print sumatorio([1, 2, 3])
