letra = raw_input('Dame una letra min�scula: ')

if letra <= 'k':
  print 'Es de las primeras del alfabeto'
if letra >= 'l':
  print 'Es de las �ltimas del alfabeto'
