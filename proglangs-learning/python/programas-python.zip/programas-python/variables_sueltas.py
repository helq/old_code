def mostrar_persona(nombre, dni, edad):
  print 'Nombre:', nombre
  print 'DNI:   ', dni
  print 'Edad:  ', edad

nombre   = 'Juan Paz'
dni      = '12345678Z'
edad     = 19

otronombre   = 'Ana Mir'
otrodni      = '23456789D'
otraedad     = 18

mostrar_persona(nombre, dni, edad)
mostrar_persona(otronombre, otrodni, otraedad)
