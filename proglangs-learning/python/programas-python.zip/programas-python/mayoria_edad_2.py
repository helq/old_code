def mayoria_de_edad(edad):
  if edad < 18:
    return False
  return True
