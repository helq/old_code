i = int(raw_input('Valor inicial: '))
while i < 10:
  print i
  i += 1
