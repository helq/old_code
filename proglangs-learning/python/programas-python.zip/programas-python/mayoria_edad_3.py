def mayoria_de_edad(edad):
  return edad >= 18
