def sumatorio(lista):
  s = 0
  for numero in lista:
    s += numero
  return s
