sumatorio = 0
i = 0
while i < 1000:
  i += 1
  sumatorio += i
print sumatorio
