for i in range(0, 4):
  for j in range(0, 4):
    for k in range(i, j):
      print i, j, k
