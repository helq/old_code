x = 500
y = 500
radio = 500
create_circle(x, y, radio)
