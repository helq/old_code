h = float(raw_input('Dame h: ')) 
v = float(raw_input('y v: ')) 
z = h * v                           
print 'Resultado 1 %6.2f' % z       
v = 2 * h + v + v 
print 'Resultado 2 %6.2f'  % v       
