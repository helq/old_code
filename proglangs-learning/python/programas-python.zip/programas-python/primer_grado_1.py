a = float(raw_input('Valor de a: ')) 
b = float(raw_input('Valor de b: '))

x = -b / a

print 'Soluci�n: ', x
