from math import pi

texto_leido = raw_input()
radio = float(texto_leido)
volumen = 4.0 / 3.0 * pi * radio ** 3

print volumen
