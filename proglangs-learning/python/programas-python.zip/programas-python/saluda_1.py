nombre = raw_input('Tu nombre: ')
print 'Hola, %s.' % (nombre)
