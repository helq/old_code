num = 7

for divisor in range(2, num):
  print '%d entre %d' % (num, divisor) ,
  print 'es %d con resto %d' % (num / divisor, num % divisor)
