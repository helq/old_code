def cuadrado(x):
  return x ** 2
