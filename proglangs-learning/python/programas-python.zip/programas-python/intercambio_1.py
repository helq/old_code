def intento_de_intercambio(a, b):
  aux = a
  a = b
  b = aux

lista1 = [1, 2]
lista2 = [3, 4]

intento_de_intercambio(lista1, lista2)

print lista1
print lista2
