for nombre in ['Pepe', 'Ana', 'Juan']:
  print 'Hola, %s.' % nombre
