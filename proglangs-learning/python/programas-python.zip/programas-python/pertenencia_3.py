conjunto = [1, 2, 3]
elemento = int(raw_input('Dame un n�mero: '))
if not elemento in conjunto:
  conjunto.append(elemento)
