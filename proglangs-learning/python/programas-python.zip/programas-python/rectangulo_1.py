def area_rectangulo(altura, anchura):
  return altura * anchura

print area_rectangulo(3, 4)
