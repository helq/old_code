def cuadrado(x):
  return x * x
