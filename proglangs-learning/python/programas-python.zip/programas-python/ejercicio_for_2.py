for i in range(0, 5):
  for j in range(i, 5):
    print i, j
