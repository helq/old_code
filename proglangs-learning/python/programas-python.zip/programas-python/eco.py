from sys import stdin

for linea in stdin:
  print linea
