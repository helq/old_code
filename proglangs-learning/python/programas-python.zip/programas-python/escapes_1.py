from gravedad import velocidad_escape, ve_Tierra

print 'La velocidad de escape de Plut�n es',
print 'de', velocidad_escape(1.29e22, 1.16e6), 'm/s.'
print 'La de la Tierra es de', ve_Tierra, 'm/s.'
