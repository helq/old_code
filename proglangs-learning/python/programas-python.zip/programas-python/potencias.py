numero = int(raw_input('Dame un n�mero: '))

for potencia in [2, 3, 4, 5]:
  print '%d elevado a %d es %d' % (numero, potencia, numero ** potencia) 
