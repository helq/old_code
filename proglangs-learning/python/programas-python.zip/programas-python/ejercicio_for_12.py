for i in range(1, 5):
  for j in range(0, 10, i):
    print i, j
