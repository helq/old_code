i = 0
while i < 1000:
  print i
  i += 1
print 'Hecho'
