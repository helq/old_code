x = 500
y = 500
radio = 500
create_circle(x, y, radio)
create_line(x, y, x+radio, y)
