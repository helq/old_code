def invierte(lista):
  for i in range(len(lista)):
    intercambiar los elementos lista[i] y lista[len(lista)-1-i]
