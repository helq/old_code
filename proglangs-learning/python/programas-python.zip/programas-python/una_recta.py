create_line(100,100, 900,900)
