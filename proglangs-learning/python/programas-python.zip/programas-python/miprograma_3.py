#! /usr/bin/env python

from math import pi

radio = 1
perimetro = 2 * pi * radio

print perimetro
