for i in range(0, 5):
  for j in range(0, i):
    print i, j
