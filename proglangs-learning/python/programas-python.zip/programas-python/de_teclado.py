from sys import stdin

print 'Teclea un texto y pulsa retorno de carro'
linea = stdin.readline()
print linea
