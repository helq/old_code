i = int(raw_input('Valor inicial: '))
limite = int(raw_input('L�mite: '))
while i < limite:
  print i
  i += 1
