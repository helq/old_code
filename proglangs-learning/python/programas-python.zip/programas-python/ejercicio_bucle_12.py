i = 1
while i < 100:
  i *= 2
  print i
