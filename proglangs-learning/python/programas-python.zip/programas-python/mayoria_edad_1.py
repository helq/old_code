def es_mayor_de_edad(edad):
  if edad < 18:
    resultado = False
  else:
    resultado = True
  return resultado
