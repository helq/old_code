# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'edytor.ui'
#
# Created: Tue Oct 29 13:35:37 2013
#      by: PyQt4 UI code generator 4.10.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_notepad(object):
    def setupUi(self, notepad):
        notepad.setObjectName(_fromUtf8("notepad"))
        notepad.setEnabled(True)
        notepad.resize(455, 314)
        self.gridLayout = QtGui.QGridLayout(notepad)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.button_open = QtGui.QPushButton(notepad)
        self.button_open.setObjectName(_fromUtf8("button_open"))
        self.horizontalLayout_2.addWidget(self.button_open)
        self.button_save = QtGui.QPushButton(notepad)
        self.button_save.setEnabled(False)
        self.button_save.setObjectName(_fromUtf8("button_save"))
        self.horizontalLayout_2.addWidget(self.button_save)
        self.button_close = QtGui.QPushButton(notepad)
        self.button_close.setObjectName(_fromUtf8("button_close"))
        self.horizontalLayout_2.addWidget(self.button_close)
        self.gridLayout.addLayout(self.horizontalLayout_2, 0, 0, 1, 1)
        self.stackedWidget = QtGui.QStackedWidget(notepad)
        self.stackedWidget.setObjectName(_fromUtf8("stackedWidget"))
        self.stackedWidgetPage1 = QtGui.QWidget()
        self.stackedWidgetPage1.setObjectName(_fromUtf8("stackedWidgetPage1"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.stackedWidgetPage1)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.editor_window = QtGui.QTextEdit(self.stackedWidgetPage1)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Monospace"))
        self.editor_window.setFont(font)
        self.editor_window.setObjectName(_fromUtf8("editor_window"))
        self.horizontalLayout.addWidget(self.editor_window)
        self.stackedWidget.addWidget(self.stackedWidgetPage1)
        self.stackedWidgetPage2 = QtGui.QWidget()
        self.stackedWidgetPage2.setObjectName(_fromUtf8("stackedWidgetPage2"))
        self.stackedWidget.addWidget(self.stackedWidgetPage2)
        self.gridLayout.addWidget(self.stackedWidget, 1, 0, 1, 1)

        self.retranslateUi(notepad)
        self.stackedWidget.setCurrentIndex(1)
        QtCore.QObject.connect(self.button_close, QtCore.SIGNAL(_fromUtf8("clicked()")), notepad.close)
        QtCore.QMetaObject.connectSlotsByName(notepad)

    def retranslateUi(self, notepad):
        notepad.setWindowTitle(_translate("notepad", "Form", None))
        self.button_open.setText(_translate("notepad", "Open file", None))
        self.button_save.setText(_translate("notepad", "Save", None))
        self.button_close.setText(_translate("notepad", "Close", None))

