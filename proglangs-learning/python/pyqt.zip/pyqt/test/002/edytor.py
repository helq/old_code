# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'edytor.ui'
#
# Created: Sun Oct 27 21:59:40 2013
#      by: PyQt4 UI code generator 4.10.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_notepad(object):
    def setupUi(self, notepad):
        notepad.setObjectName(_fromUtf8("notepad"))
        notepad.setEnabled(True)
        notepad.resize(455, 314)
        self.gridLayout = QtGui.QGridLayout(notepad)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.button_open = QtGui.QPushButton(notepad)
        self.button_open.setObjectName(_fromUtf8("button_open"))
        self.gridLayout.addWidget(self.button_open, 0, 0, 1, 1)
        self.editor_window = QtGui.QTextEdit(notepad)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Monospace"))
        self.editor_window.setFont(font)
        self.editor_window.setObjectName(_fromUtf8("editor_window"))
        self.gridLayout.addWidget(self.editor_window, 1, 0, 1, 3)
        self.button_close = QtGui.QPushButton(notepad)
        self.button_close.setObjectName(_fromUtf8("button_close"))
        self.gridLayout.addWidget(self.button_close, 0, 2, 1, 1)
        self.button_save = QtGui.QPushButton(notepad)
        self.button_save.setEnabled(False)
        self.button_save.setObjectName(_fromUtf8("button_save"))
        self.gridLayout.addWidget(self.button_save, 0, 1, 1, 1)

        self.retranslateUi(notepad)
        QtCore.QObject.connect(self.button_close, QtCore.SIGNAL(_fromUtf8("clicked()")), notepad.close)
        QtCore.QMetaObject.connectSlotsByName(notepad)

    def retranslateUi(self, notepad):
        notepad.setWindowTitle(_translate("notepad", "Form", None))
        self.button_open.setText(_translate("notepad", "Open file", None))
        self.button_close.setText(_translate("notepad", "Close", None))
        self.button_save.setText(_translate("notepad", "Save", None))

