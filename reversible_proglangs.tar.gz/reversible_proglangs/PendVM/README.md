# PendVM
PendVM is a virtual machine for running programs written in the PISA assembly language. It was written in the mid 1990's by Matt Debergalis and Mike P. Frank from the MIT AI lab as part of their work on the Pendulum processor.

Since then it has completely fallen off the web so i am rehosting it here. I've fixed two minor issues with the code but since it is (almost) pure ANSI C it should compile and run anywhere.
