module Jana.Ast where

import           Text.Parsec.Pos (SourcePos)

-- Data types
data Type
    = Int SourcePos
    | Float SourcePos
    | Stack SourcePos
    | BoolT SourcePos
    deriving (Show)

instance Eq Type where
  (Int _)   == (Int _)   = True
  (Stack _) == (Stack _) = True
  (BoolT _) == (BoolT _) = True
  (Float _) == (Float _) = True
  _         == _         = False

-- Identifier
data Ident =
  Ident String SourcePos
  deriving (Show)

instance Eq Ident where
  (Ident name1 _) == (Ident name2 _) = name1 == name2

-- Left-value
data Lval
    = Var    Ident
    | Lookup Ident Expr
    deriving (Eq, Show)

-- Modification operators used in assignment
data ModOp
    = AddEq -- +=
    | SubEq -- -=
    | XorEq -- ^=
    deriving (Eq, Show)

data UnaryOp
    = Not
    deriving (Eq, Ord, Show)

-- Binary operators
data BinOp
    = Add | Sub | Mul | Div | Mod     -- Arithmetic (+ - * / %)
    | And | Or | Xor                  -- Binary (& | ^)
    | LAnd | LOr                      -- Logical (&& ||)
    | GT | LT | EQ | NEQ | GE | LE    -- Relational (> < = != >= <=)
    deriving (Eq, Ord, Show)

-- Statement
data Stmt
    = Assign   ModOp Lval Expr SourcePos
    | If       Expr [Stmt] [Stmt] Expr SourcePos
    | From     Expr [Stmt] [Stmt] Expr SourcePos
    | Push     Ident Ident SourcePos
    | Pop      Ident Ident SourcePos
    | Local    (Type, Ident, Expr) [Stmt] (Type, Ident, Expr) SourcePos
    | Call     Ident [Ident] SourcePos
    | Uncall   Ident [Ident] SourcePos
    | UserError String [Expr] SourcePos
    | Swap     Lval Lval SourcePos
    | Prints   Prints SourcePos
    | Skip SourcePos
    deriving (Eq, Show)

-- Expression
data Expr
    = Number   Integer SourcePos
    | NumberF  Double SourcePos
    | Boolean  Bool SourcePos
    | LV       Lval SourcePos
    | UnaryOp  UnaryOp Expr
    | BinOp    BinOp Expr Expr
    | Empty    Ident SourcePos
    | Top      Ident SourcePos
    | Size     Ident SourcePos
    | Nil      SourcePos
    deriving (Eq, Show)

-- Declaration
data Vdecl
    = Scalar Type Ident SourcePos
    | Array  Type Ident (Maybe Integer) SourcePos
    deriving (Eq, Show)

data Prints
    = Print String
    | Printf String [Expr]
    | Show [Ident]
    deriving (Eq, Show)

-- Main procedure
data ProcMain
    = ProcMain [Vdecl] [Stmt] SourcePos
    deriving (Eq, Show)

-- Procedure definition
data Proc
    = Proc { procname :: Ident
           , params   :: [Vdecl]   -- Zero or more
           , body     :: [Stmt]
           }
    deriving (Eq, Show)

data Program = Program [ProcMain] [Proc]
  deriving (Show)


class Identifiable a where
  ident :: a -> String

instance Identifiable Ident where
  ident (Ident id_ _) = id_

instance Identifiable Lval where
  ident (Var id_)      = ident id_
  ident (Lookup id_ _) = ident id_

instance Identifiable Vdecl where
  ident (Scalar _ id_ _) = ident id_
  ident (Array _ id_ _ _)  = ident id_

instance Identifiable ProcMain where
  ident _ = "main"

instance Identifiable Proc where
  ident proc = ident $ procname proc
