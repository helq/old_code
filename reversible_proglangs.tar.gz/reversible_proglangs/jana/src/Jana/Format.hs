module Jana.Format where

import           Data.List        (intersperse)
import qualified Data.Map         as Map
import qualified Data.Monoid as M ((<>))
import           Jana.Ast
import           Prelude          hiding (EQ, GT, LT)
import           Text.PrettyPrint (Doc, brackets, char, comma, empty, equals,
                                   hsep, integer, double, nest, parens, punctuate,
                                   render, text, vcat, ($+$), (<+>), (<>))


commasep :: [Doc] -> Doc
commasep = hsep . punctuate (char ',')


formatType :: Type -> Doc
formatType (Int _)   = text "int"
formatType (Float _) = text "float"
formatType (Stack _) = text "stack"
formatType v         = error $ "This variable type `" M.<> show v M.<> "` cannot be declared directly"

formatIdent :: Ident -> Doc
formatIdent id_ = text (ident id_)

formatLval :: Lval -> Doc
formatLval (Var id_)         = formatIdent id_
formatLval (Lookup id_ expr) = formatIdent id_ <> brackets (formatExpr expr)

formatModOp :: ModOp -> Doc
formatModOp AddEq = text "+="
formatModOp SubEq = text "-="
formatModOp XorEq = text "^="

-- Operators and their precedence
-- Should match the operator table in Jana.Parser
unaryOpMap :: Map.Map UnaryOp (String, Integer)
unaryOpMap = Map.fromList [
    (Not,  ("!",  5))
  ]
binOpMap :: Map.Map BinOp (String, Integer)
binOpMap = Map.fromList [
    (Mul , ("*",  4))
  , (Div , ("/",  4))
  , (Mod , ("%",  4))

  , (Add , ("+",  3))
  , (Sub , ("-",  3))

  , (GE  , (">=", 2))
  , (GT  , (">",  2))
  , (LE  , ("<=", 2))
  , (LT  , ("<",  2))
  , (EQ  , ("=",  2))
  , (NEQ , ("!=", 2))

  , (And , ("&",  1))
  , (Or  , ("|",  1))
  , (Xor , ("^",  1))

  , (LAnd, ("&&", 0))
  , (LOr , ("||", 0))
  ]


formatUnaryOp :: UnaryOp -> Doc
formatUnaryOp = text . fst . (unaryOpMap Map.!)
formatBinOp :: BinOp -> Doc
formatBinOp = text . fst . (binOpMap Map.!)


formatExpr :: Expr -> Doc
formatExpr = f (0 :: Integer)
  where f _ (Number num _)    = integer num
        f _ (NumberF num _)   = double num
        f _ (Boolean True _)  = text "true"
        f _ (Boolean False _) = text "false"
        f _ (LV lval _)       = formatLval lval
        f _ (Empty id_ _)      = text "empty" <> parens (formatIdent id_)
        f _ (Top id_ _)        = text "top" <> parens (formatIdent id_)
        f _ (Size id_ _)       = text "size" <> parens (formatIdent id_)
        f _ (Nil _)           = text "nil"
        f d (UnaryOp op e)    =
          let opd = unaryOpPrec op in
            parens' (d > opd) (formatUnaryOp op <> f opd e)
        f d (BinOp op e1 e2)  =
          let opd = binOpPrec op in
            parens' (d > opd) (f opd e1 <+> formatBinOp op <+> f opd e2)
        unaryOpPrec  = snd . (unaryOpMap Map.!)
        binOpPrec    = snd . (binOpMap Map.!)
        parens' bool = if bool then parens else id


formatVdecl :: Vdecl -> Doc
formatVdecl (Scalar typ id_ _) =
  formatType typ <+> formatIdent id_

formatVdecl (Array t id_ size _) =
  text type_ <+> formatIdent id_ <> brackets (formatSize size)
  where formatSize (Just x) = integer x
        formatSize Nothing  = empty
        type_ = case t of
                  (Int _)   -> "int"
                  (Float _) -> "float"
                  _         -> error "Only arrays of type int and float can be declared"


formatStmts :: [Stmt] -> Doc
formatStmts = vcat . map formatStmt


formatStmt :: Stmt -> Doc
formatStmt (Assign modOp lval expr _) =
  formatLval lval <+> formatModOp modOp <+> formatExpr expr

formatStmt (If e1 s1 s2 e2 _) =
  text "if" <+> formatExpr e1 <+> text "then" $+$
    nest 4 (formatStmts s1) $+$
  elsePart $+$
  text "fi" <+> formatExpr e2
  where elsePart | null s2   = empty
                 | otherwise = text "else" $+$ nest 4 (formatStmts s2)

formatStmt (From e1 s1 s2 e2 _) =
  text "from" <+> formatExpr e1 <+> keyword $+$
    vcat inside $+$
  text "until" <+> formatExpr e2
  where (keyword:inside) = doPart ++ loopPart
        doPart   | null s1   = []
                 | otherwise = [text "do", nest 4 (formatStmts s1)]
        loopPart | null s2   = [empty]
                 | otherwise = [text "loop", nest 4 (formatStmts s2)]

formatStmt (Push id1 id2 _) =
  text "push" <> parens (formatIdent id1 <> comma <+> formatIdent id2)

formatStmt (Pop id1 id2 _) =
  text "pop" <> parens (formatIdent id1 <> comma <+> formatIdent id2)

formatStmt (Local (typ1, id1, e1) s (typ2, id2, e2) _) =
  text "local" <+> localDecl typ1 id1 e1 $+$
  formatStmts s $+$
  text "delocal" <+> localDecl typ2 id2 e2
  where localDecl typ id_ expr =
          formatType typ <+> formatIdent id_ <+> equals <+> formatExpr expr

formatStmt (Call id_ args _) =
  text "call" <+> formatIdent id_ <> parens (commasep $ map formatIdent args)

formatStmt (Uncall id_ args _) =
  text "uncall" <+> formatIdent id_ <> parens (commasep $ map formatIdent args)

formatStmt (Swap id1 id2 _) =
  formatLval id1 <+> text "<=>" <+> formatLval id2

formatStmt (UserError msg [] _) =
  text "error" <> parens (text (show msg))

formatStmt (UserError msg exprs _) =
  text "error" <> parens (text (show msg) <> comma <+> commasep (map formatExpr exprs))

formatStmt (Prints (Print str) _) =
  text "print" <> parens (text (show str))

formatStmt (Prints (Printf str []) _) =
  text "printf" <> parens (text (show str))

formatStmt (Prints (Printf str exprs) _) =
  text "printf" <> parens (text (show str) <> comma <+> commasep (map formatExpr exprs))

formatStmt (Prints (Show idents) _) =
  text "show" <> parens (commasep $ map formatIdent idents)

formatStmt (Skip _) =
  text "skip"


formatStmtsAbbrv :: [Stmt] -> Doc
formatStmtsAbbrv []         = empty
formatStmtsAbbrv [If {}]    = text "..."
formatStmtsAbbrv [From {}]  = text "..."
formatStmtsAbbrv [Local {}] = text "..."
formatStmtsAbbrv [s]        = formatStmt s
formatStmtsAbbrv _          = text "..."


formatStmtAbbrv :: Stmt -> Doc
formatStmtAbbrv (If e1 s1 s2 e2 _) =
  text "if" <+> formatExpr e1 <+> text "then" $+$
    nest 4 (formatStmtsAbbrv s1) $+$
  elsePart $+$
  text "fi" <+> formatExpr e2
  where elsePart | null s2   = empty
                 | otherwise = text "else" $+$ nest 4 (formatStmtsAbbrv s2)

formatStmtAbbrv (From e1 s1 s2 e2 _) =
  text "from" <+> formatExpr e1 <+> keyword $+$
    vcat inside $+$
  text "until" <+> formatExpr e2
  where (keyword:inside) = doPart ++ loopPart
        doPart   | null s1   = []
                 | otherwise = [text "do", nest 4 (formatStmtsAbbrv s1)]
        loopPart | null s2   = [empty]
                 | otherwise = [text "loop", nest 4 (formatStmtsAbbrv s2)]

formatStmtAbbrv (Local (typ1, id1, e1) s (typ2, id2, e2) _) =
  text "local" <+> localDecl typ1 id1 e1 $+$
  formatStmtsAbbrv s $+$
  text "delocal" <+> localDecl typ2 id2 e2
  where localDecl typ id_ expr =
          formatType typ <+> formatIdent id_ <+> equals <+> formatExpr expr

formatStmtAbbrv s = formatStmt s


formatMain :: ProcMain -> Doc
formatMain (ProcMain vdecls body_ _) =
  text "procedure main()" $+$
    nest 4 (vcat (map formatVdecl vdecls) $+$
            text "" $+$
            formatStmts body_)


formatParams :: [Vdecl] -> Doc
formatParams = commasep . map formatVdecl

formatProc :: Proc -> Doc
formatProc proc =
  text "procedure" <+> formatIdent (procname proc) <>
  parens (formatParams $ params proc) $+$
    nest 4 (formatStmts $ body proc)


formatProgram :: Program -> Doc
formatProgram (Program [main] procs) =
  vcat (intersperse (text "") $ map formatProc procs) $+$
  text "" $+$
  formatMain main
