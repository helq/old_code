{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE RankNTypes                 #-}

module Jana.Types (
    ArrayRaw(..), lenArrayRaw, Stack,
    Value(..), nil, performOperation, performModOperation,
    showValueType, typesMatch, truthy,
    JType(..), extractType, showType,
    Store, printVdecl, showStore, emptyStore, storeFromList,
    getRef, getVar, getRefValue, bindVar, unbindVar, setVar,
    EvalEnv(..),
    EvalOptions(..), defaultOptions,
    ProcEnv, emptyProcEnv, procEnvFromList, getProc,
    Eval, runEval, (<!!>)
    ) where

import           Control.Applicative    ()
import           Control.Monad          (foldM)
import           Control.Monad.Except   (ExceptT, MonadError, runExceptT,
                                         throwError)
import           Control.Monad.IO.Class (liftIO)
import           Control.Monad.Reader   (MonadReader, ReaderT, asks, runReaderT)
import           Control.Monad.State    (MonadIO, MonadState, StateT, ap, get,
                                         liftM, modify, put, runStateT, when)
import           Data.Bits              (xor, (.&.), (.|.))
import           Data.IORef             (IORef, newIORef, readIORef, writeIORef)
import           Data.List              (intercalate)
import qualified Data.Map               as Map
import           Prelude                hiding (EQ, GT, LT)
import           Text.Parsec.Pos        (SourcePos)
import           Text.Printf            (printf)

import qualified Data.Monoid as M ((<>))
import           Data.Fixed (Fixed, E12, mod', div', showFixed)

import           Jana.Aliases
import           Jana.Ast
import           Jana.Error
import           Jana.ErrorMessages

{-import Debug.Trace (trace)-}

type Stack = [Integer]

data ArrayRaw
  = ArrayInt [Integer]
  | ArrayFloat [Fixed E12]
  deriving (Eq)

lenArrayRaw :: ArrayRaw -> Int
lenArrayRaw (ArrayInt xs)   = length xs
lenArrayRaw (ArrayFloat xs) = length xs

-- Types of values an expression can evaluate to.
data Value
  = JInt Integer
  | JFloat (Fixed E12)
  | JBool Bool
  | JArray JType ArrayRaw
  | JStack Stack
  deriving (Eq)

instance Show Value where
  show (JInt x)    = show x
  show (JFloat x)  = showFixed True x
  show (JArray _ (ArrayInt xs)) = "{" ++ intercalate ", " (map show xs) ++ "}"
  show (JArray _ (ArrayFloat xs)) = "{" ++ intercalate ", " (map (showFixed True) xs) ++ "}"
  show (JStack []) = "nil"
  show (JStack xs) = "<" ++ intercalate ", " (map show xs) ++ "]"
  show (JBool _)   = error "boolean variables cannot be daclared"

showValueType :: Value -> String
showValueType (JInt _)          = "int"
showValueType (JFloat _)        = "float"
showValueType (JStack _)        = "stack"
showValueType (JArray TInt _)   = "array of ints"
showValueType (JArray TFloat _) = "array of floats"
showValueType (JBool _)         = "bool"

typesMatch :: Value -> Value -> Bool
typesMatch (JArray x _) (JArray y _) = x == y
typesMatch (JInt _) (JInt _)     = True
typesMatch (JFloat _) (JFloat _) = True
typesMatch (JStack _) (JStack _) = True
typesMatch (JBool _) (JBool _)   = True
typesMatch _ _                   = False

nil :: Value
nil = JStack []

truthy :: Value -> Bool
truthy (JInt 0)    = False
truthy (JFloat 0)  = False
truthy (JStack []) = False
truthy _           = True

data JType = TInt | TFloat | TBool | TArrayInts | TArrayFloats | TStack
  deriving (Eq)

extractType :: Value -> JType
extractType (JInt _)          = TInt
extractType (JFloat _)        = TFloat
extractType (JBool _)         = TBool
extractType (JArray TInt _)   = TArrayInts
extractType (JArray TFloat _) = TArrayFloats
extractType (JStack _)        = TStack

showType :: JType -> String
showType TInt         = "int"
showType TFloat       = "float"
showType TStack       = "stack"
showType TArrayInts   = "array of ints"
showType TArrayFloats = "array of floats"
showType TBool        = "bool"

{-
 -boolToInt :: Num a => (a -> a -> Bool) -> a -> a -> a
 -boolToInt f x y = if f x y then 1 else 0
 -}

wrap :: (a -> Value) -> (b -> c -> a) -> b -> c -> Value
wrap m f x y = m $ f x y


opFunc :: BinOp -> Integer -> Integer -> Value
opFunc Add  = wrap JInt (+)
opFunc Sub  = wrap JInt (-)
opFunc Mul  = wrap JInt (*)
opFunc Div  = wrap JInt div
opFunc Mod  = wrap JInt mod
opFunc And  = wrap JInt (.&.)
opFunc Or   = wrap JInt (.|.)
opFunc Xor  = wrap JInt xor
opFunc LAnd = undefined -- handled by evalExpr
opFunc LOr  = undefined -- handled by evalExpr
opFunc GT   = wrap JBool (>)
opFunc LT   = wrap JBool (<)
opFunc EQ   = wrap JBool (==)
opFunc NEQ  = wrap JBool (/=)
opFunc GE   = wrap JBool (>=)
opFunc LE   = wrap JBool (<=)

opFunc2 :: BinOp -> Fixed E12 -> Fixed E12 -> Value
opFunc2 Add  = wrap JFloat (+)
opFunc2 Sub  = wrap JFloat (-)
opFunc2 Mul  = wrap JFloat (*)
opFunc2 Div  = wrap JFloat (/)
opFunc2 LAnd = undefined -- handled by evalExpr
opFunc2 LOr  = undefined -- handled by evalExpr
opFunc2 GT   = wrap JBool (>)
opFunc2 LT   = wrap JBool (<)
opFunc2 EQ   = wrap JBool (==)
opFunc2 NEQ  = wrap JBool (/=)
opFunc2 GE   = wrap JBool (>=)
opFunc2 LE   = wrap JBool (<=)
opFunc2 op   = error $ "Operation " M.<> show op M.<> " undefined for `float` number type"

performOperation :: BinOp -> Value -> Value -> SourcePos -> SourcePos -> Eval Value
performOperation Div (JInt _) (JInt 0) _ pos =
  pos <!!> divisionByZero
performOperation op (JInt x) (JInt y) _ _ =
  return $ opFunc op x y
performOperation Div (JFloat _) (JFloat 0) _ pos =
  pos <!!> divisionByZero
performOperation op (JFloat x) (JFloat y) _ _ =
  return $ opFunc2 op x y
performOperation _ (JInt _) val _ pos =
  pos <!!> typeMismatch ["int"] (showValueType val)
performOperation _ (JFloat _) val _ pos =
  pos <!!> typeMismatch ["float"] (showValueType val)
performOperation _ val _ pos _ =
  pos <!!> typeMismatch ["int", "float"] (showValueType val)

performModOperation :: ModOp -> Value -> Value -> SourcePos -> SourcePos -> Eval Value
performModOperation modOp = performOperation $ modOpToBinOp modOp
  where modOpToBinOp AddEq = Add
        modOpToBinOp SubEq = Sub
        modOpToBinOp XorEq = Xor

--
-- Environment
--

type Store = Map.Map String (IORef Value)

printVdecl :: String -> Value -> String
printVdecl name val@(JArray _ axs) = printf "%s[%d] = %s" name (lenArrayRaw axs) (show val)
printVdecl name val = printf "%s = %s" name (show val)

showStore :: Store -> IO String
showStore store =
  fmap (intercalate "\n")
        (mapM (\(name, ref) -> fmap (printVdecl name) (readIORef ref))
              (Map.toList store))

emptyStore :: Map.Map k a
emptyStore = Map.empty

storeFromList :: [(String, IORef Value)] -> Store
storeFromList = Map.fromList

getRef :: Ident -> Eval (IORef Value)
getRef (Ident name pos) =
  do storeEnv <- get
     case Map.lookup name storeEnv of
       Just ref -> return ref
       Nothing  -> pos <!!> unboundVar name

getVar :: Ident -> Eval Value
getVar id_ = getRef id_ >>= liftIO . readIORef

getRefValue :: IORef Value -> Eval Value
getRefValue = liftIO . readIORef

-- Bind a variable name to a new reference
bindVar :: Ident -> Value -> Eval ()
bindVar (Ident name pos) val =
  do storeEnv <- get
     ref <- liftIO $ newIORef val
     case Map.lookup name storeEnv of
       Nothing -> put $ Map.insert name ref storeEnv
       Just _  -> pos <!!> alreadyBound name

unbindVar :: Ident -> Eval ()
unbindVar = modify . Map.delete . ident

-- Set the value of a variable (modifying the reference)
setVar :: Ident -> Value -> Eval ()
setVar id_ val =
  do ref <- getRef id_
     liftIO $ writeIORef ref val


data EvalEnv = EE { evalOptions :: EvalOptions
                  , procEnv     :: ProcEnv
                  , aliases     :: AliasSet }

data EvalOptions = EvalOptions { modInt :: Bool, runReverse :: Bool }
defaultOptions :: EvalOptions
defaultOptions   = EvalOptions { modInt = False, runReverse = False }

type ProcEnv = Map.Map String Proc

emptyProcEnv :: forall k a. Map.Map k a
emptyProcEnv = Map.empty

procEnvFromList :: [Proc] -> Either JanaError ProcEnv
procEnvFromList = foldM insertProc emptyProcEnv
  where insertProc env p = if Map.notMember (ident p) env
                             then if checkDuplicateArgs (makeIdentList p)
                                    then Right (Map.insert (ident p) p env)
                                    else Left $ newErrorMessage (ppos p) (procDuplicateArgs p)
                             else Left  $ newErrorMessage (ppos p) (procDefined p)
        ppos  Proc { procname = (Ident _ pos) } = pos

makeIdentList :: Proc -> [Ident]
makeIdentList Proc{params = params_} = map getVdeclIdent params_
  where
    getVdeclIdent (Scalar _ id_ _)  = id_
    getVdeclIdent (Array _ id_ _ _) = id_

checkDuplicateArgs :: [Ident] -> Bool
checkDuplicateArgs []         = True
checkDuplicateArgs [_]        = True
checkDuplicateArgs (arg:args) = arg `notElem` args && checkDuplicateArgs args

getProc :: Ident -> Eval Proc
getProc (Ident funName pos) =
  do when (funName == "main") $ pos <!!> callingMainError
     procEnv_ <- asks procEnv
     case Map.lookup funName procEnv_ of
       Just proc -> return proc
       Nothing   -> pos <!!> undefProc funName


--
-- Evaluation
--

instance Functor Eval where
    fmap  = liftM

instance Applicative Eval where
    pure  = return
    (<*>) = ap  -- defined in Control.Monad

newtype Eval a = E { runE :: StateT Store (ReaderT EvalEnv (ExceptT JanaError IO)) a }
               deriving (Monad, MonadIO, MonadError JanaError, MonadReader EvalEnv, MonadState Store)

runEval :: Eval a -> Store -> EvalEnv -> IO (Either JanaError (a, Store))
runEval eval store procs = runExceptT (runReaderT (runStateT (runE eval) store) procs)

throwJanaError :: SourcePos -> Message -> Eval a
throwJanaError pos msg = throwError $ newErrorMessage pos msg

infixr 1 <!!>
(<!!>) :: SourcePos -> Message -> Eval a
pos <!!> msg = throwJanaError pos msg
