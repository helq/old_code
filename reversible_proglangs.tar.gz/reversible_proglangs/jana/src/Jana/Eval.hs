module Jana.Eval (
  runProgram,
  evalLval,
  evalExpr,
  runEval,
  ) where


import           Control.Monad          (unless, when)
import           Control.Monad.Except   (catchError, throwError)
import           Control.Monad.IO.Class (liftIO)
import           Control.Monad.Reader   (asks, local)
import           Control.Monad.State    (get, put)
import           Data.Char              (toLower)
import           Data.List              (genericReplicate, genericSplitAt,
                                         intercalate)
import           Prelude                hiding (EQ, GT, LT, userError)
import           System.Exit            (ExitCode (ExitFailure), exitWith)

import           Text.Parsec.Pos        (SourcePos)

import           Data.Fixed (Fixed, E12)

import           Jana.Aliases
import           Jana.Ast
import           Jana.Error
import           Jana.ErrorMessages
import           Jana.Invert
import           Jana.Printf
import           Jana.Types

{-import Debug.Trace (trace)-}

inArgument :: String -> String -> Eval a -> Eval a
inArgument funid argid monad = catchError monad $
  throwError . addErrorMessage (InArgument funid argid)

inExpression :: Expr -> Eval a -> Eval a
inExpression expr monad = catchError monad $
  throwError . addOnceErrorMessage (InExpression expr)

inStatement :: Stmt -> Eval a -> Eval a
inStatement stmt monad = catchError monad $
  \err -> do storeStr <- get >>= liftIO . showStore
             throwError $ addErrorMessage (InStatement stmt storeStr) err

inProcedure :: Proc -> Eval a -> Eval a
inProcedure proc monad = catchError monad $
  throwError . addErrorMessage (InProcedure $ ident proc)


unpackInt :: SourcePos -> Value -> Eval Integer
unpackInt _ (JInt x) = return x
unpackInt pos val    = pos <!!> typeMismatch ["int"] (showValueType val)

unpackIntFloat :: SourcePos -> Value -> Eval (Either Integer (Fixed E12))
unpackIntFloat _ (JInt x) = return (Left x)
unpackIntFloat _ (JFloat x) = return (Right x)
unpackIntFloat pos val = pos <!!> typeMismatch ["int", "float"] (showValueType val)

unpackArray :: SourcePos -> JType -> Value -> Eval ArrayRaw
unpackArray _ TInt   (JArray TInt x@(ArrayInt _))     = return x
unpackArray _ TFloat (JArray TFloat x@(ArrayFloat _)) = return x
unpackArray pos _ val@(JArray TInt _)   = pos <!!> typeMismatch ["array of ints"] (showValueType val)
unpackArray pos _ val@(JArray TFloat _) = pos <!!> typeMismatch ["array of floats"] (showValueType val)
unpackArray pos _ val = pos <!!> typeMismatch ["array"] (showValueType val)

unpackArray' :: SourcePos -> Value -> Eval (ArrayRaw, JType)
unpackArray' _ (JArray TInt x)   = return (x, TInt)
unpackArray' _ (JArray TFloat x) = return (x, TFloat)
unpackArray' pos val@(JArray TInt x) = pos <!!> typeMismatch ["array of ints"] (showValueType val)
unpackArray' pos val@(JArray TFloat x) = pos <!!> typeMismatch ["array of float"] (showValueType val)
unpackArray' pos val = pos <!!> typeMismatch ["array"] (showValueType val)

unpackStack :: SourcePos -> Value -> Eval Stack
unpackStack _ (JStack x) = return x
unpackStack pos val      = pos <!!> typeMismatch ["stack"] (showValueType val)

unpackBool :: SourcePos -> Value -> Eval Bool
unpackBool _ (JBool x) = return x
unpackBool pos val     = pos <!!> typeMismatch ["bool"] (showValueType val)

assert :: Bool -> Expr -> Eval ()
assert bool expr =
  do val1 <- unpackBool (getExprPos expr) =<< evalModularExpr expr
     unless (val1 == bool) $
       getExprPos expr <!!> assertionFail ("should be " ++ map toLower (show bool))

assertTrue :: Expr -> Eval ()
assertTrue  = assert True
assertFalse :: Expr -> Eval ()
assertFalse = assert False

checkType :: Type -> Value -> Eval ()
checkType (Int _)   (JInt _)          = return ()
checkType (Float _) (JFloat _)        = return ()
checkType (Int _)   (JArray TInt _)   = return ()
checkType (Float _) (JArray TFloat _) = return ()
checkType (Stack _) (JStack _) = return ()
checkType (Int pos)   val = pos <!!> typeMismatch ["int"] (showValueType val)
checkType (Float pos) val = pos <!!> typeMismatch ["float"] (showValueType val)
checkType (Stack pos) val = pos <!!> typeMismatch ["stack"] (showValueType val)
checkType (BoolT _)   _   = error "boolean variables aren't declarable"

checkVdecl :: Vdecl -> Value -> Eval ()
checkVdecl (Scalar Int {}   _ _)  (JInt _)       = return ()
checkVdecl (Scalar Stack {} _ _)  (JStack _)     = return ()
checkVdecl (Array Int{} _ Nothing  _) (JArray TInt _)     = return ()
checkVdecl (Array Int{} _ (Just x) pos) (JArray TInt arr) =
  unless (x == arrLen) $ pos <!!> arraySizeMismatch x arrLen
  where arrLen = toInteger (lenArrayRaw arr)
checkVdecl (Array Float{} _ Nothing  _) (JArray TFloat _)     = return ()
checkVdecl (Array Float{} _ (Just x) pos) (JArray TFloat arr) =
  unless (x == arrLen) $ pos <!!> arraySizeMismatch x arrLen
  where arrLen = toInteger (lenArrayRaw arr)
checkVdecl vdecl val =
  vdeclPos vdecl <!!> typeMismatch [vdeclType vdecl] (showValueType val)
  where vdeclPos (Scalar _ _ pos)  = pos
        vdeclPos (Array _ _ _ pos) = pos
        vdeclType (Scalar Int{} _ _)   = "int"
        vdeclType (Scalar Float{} _ _) = "float"
        vdeclType (Scalar Stack{} _ _) = "stack"
        vdeclType (Scalar BoolT{} _ _) = error "boolean variables aren't declarable"
        vdeclType (Array Int{} _ _ _)   = "array of ints"
        vdeclType (Array Float{} _ _ _) = "array of floats"


arrayLookup :: ArrayRaw -> Integer -> SourcePos -> Eval Value
arrayLookup arr idx pos =
  if idx < 0 || idx' >= lenArrayRaw arr
    then pos <!!> outOfBounds idx (toInteger $ lenArrayRaw arr)
    else return $ case arr of
                    ArrayInt xs   -> JInt $ xs !! idx'
                    ArrayFloat xs -> JFloat $ xs !! idx'
  where idx' = fromInteger idx

arrayModify :: ArrayRaw -> Integer -> Either Integer (Fixed E12) -> ArrayRaw
arrayModify (ArrayInt arr) idx (Left val) = ArrayInt $ xs ++ val : ys
  where (xs, _:ys) = genericSplitAt idx arr
arrayModify (ArrayFloat arr) idx (Right val) = ArrayFloat $ xs ++ val : ys
  where (xs, _:ys) = genericSplitAt idx arr

arrayModify _ _ _ = error "Type Mismatch between " -- TODO: Improve this error


getExprPos :: Expr -> SourcePos
getExprPos (Number _ pos)  = pos
getExprPos (NumberF _ pos) = pos
getExprPos (Boolean _ pos) = pos
getExprPos (LV _ pos)      = pos
getExprPos (UnaryOp _ e)   = getExprPos e
getExprPos (BinOp _ e1 _)  = getExprPos e1
getExprPos (Empty _ pos)   = pos
getExprPos (Top _ pos)     = pos
getExprPos (Size _ pos)    = pos
getExprPos (Nil pos)       = pos


runProgram :: String -> Program -> EvalOptions -> IO ()
runProgram _ (Program [main] procs) evalOptions_ =
  case procEnvFromList procs of
    Left err -> print err
    Right procEnv_ ->
      let env = EE { procEnv = procEnv_
                   , evalOptions = evalOptions_
                   , aliases = Jana.Aliases.empty }
      in do runRes <- runEval (evalMain main) emptyStore env
            case runRes of
              Right (_, s) -> showStore s >>= putStrLn
              Left err     -> print err >> exitWith (ExitFailure 1)
runProgram filename (Program [] _) _ =
  print (newFileError filename noMainProc) >> exitWith (ExitFailure 1)
runProgram filename (Program _ _) _ =
  print (newFileError filename multipleMainProcs) >> exitWith (ExitFailure 1)


evalMain :: ProcMain -> Eval ()
evalMain (ProcMain vdecls body_ _) =
  do mapM_ initBinding vdecls
     evalStmts body_
  where initBinding (Scalar (Int _) id_ _)   = bindVar id_ $ JInt 0
        initBinding (Scalar (Float _) id_ _) = bindVar id_ $ JFloat 0
        initBinding (Scalar (Stack _) id_ _) = bindVar id_ nil
        initBinding (Array _ id_ Nothing pos)  = pos <!!> arraySizeMissing id_
        initBinding (Array t id_ (Just size) pos) =
          if size < 1
            then pos <!!> arraySize
            else bindVar id_ $ initArr (type2jtype t) size
        initArr t size = JArray t $ case t of
                                      TInt   -> ArrayInt $ genericReplicate size 0
                                      TFloat -> ArrayFloat $ genericReplicate size 0
        type2jtype Int{} = TInt
        type2jtype Float{} = TFloat


evalProc :: Proc -> [Ident] -> Eval ()
evalProc proc args = inProcedure proc $
  do checkNumArgs (length vdecls) (length args)
     checkArgTypes
     oldStore <- get
     newStore <- localStore
     put newStore
     local updateAliases (evalStmts $ body proc)
     put oldStore
  where vdecls = params proc
        refs = mapM getRef args
        procPos Proc { procname = Ident _ pos } = pos
        checkNumArgs expArgs gotArgs =
          when (expArgs /= gotArgs) $
            procPos proc <!!> argumentError proc expArgs gotArgs
        checkArg (vdecl, ref) = inArgument (ident proc) (ident $ getVdeclIdent vdecl) $
          getRefValue ref >>= checkVdecl vdecl
        checkArgTypes =
          zip vdecls <$> refs >>= mapM_ checkArg
        localStore =
          fmap (storeFromList . zip (map (ident . getVdeclIdent) vdecls)) refs
        getVdeclIdent (Scalar _ id_ _)  = id_
        getVdeclIdent (Array _ id_ _ _) = id_
        updateAliases env =
          let xs = zip (map ident args) (map ident vdecls) in
            env { aliases = introAndPropAliases xs (aliases env) }


assignLval :: ModOp -> Lval -> Expr -> SourcePos -> Eval ()
assignLval modOp lv@(Var id_) expr _ =
  do exprVal <- evalModularAliasExpr lv expr
     varVal  <- getVar id_
     {-trace "entering here aren't you ;)" performModOperation modOp varVal exprVal exprPos exprPos >>= setVar id_-}
     performModOperation modOp varVal exprVal exprPos exprPos >>= setVar id_
  where exprPos = getExprPos expr
assignLval modOp (Lookup id_ idxExpr) expr pos =
  do idx    <- unpackInt exprPos =<< evalModularAliasExpr (Var id_) idxExpr
     val    <- evalModularAliasExpr (Lookup id_ (Number idx exprPos)) expr
     let type_ = extractType val
     arr    <- unpackArray pos type_ =<< getVar id_
     oldval <- arrayLookup arr idx (getExprPos idxExpr)
     newval <- unpackIntFloat pos =<< performModOperation modOp oldval val exprPos exprPos
     setVar id_ $ JArray type_ $ arrayModify arr idx newval
  where exprPos = getExprPos expr

evalStmts :: [Stmt] -> Eval ()
evalStmts = mapM_ (\stmt -> inStatement stmt $ evalStmt stmt)

evalStmt :: Stmt -> Eval ()
evalStmt (Assign modOp lval expr pos) = assignLval modOp lval expr pos
evalStmt (If e1 s1 s2 e2 _) =
  do val1 <- unpackBool (getExprPos e1) =<< evalModularExpr e1
     if val1
       then do evalStmts s1
               assertTrue e2
       else do evalStmts s2
               assertFalse e2
evalStmt (From e1 s1 s2 e2 _) =
  do assertTrue e1
     evalStmts s1
     loop
  where loop = do val <- unpackBool (getExprPos e2) =<< evalModularExpr e2
                  unless val loopRec
        loopRec = do evalStmts s2
                     assertFalse e1
                     evalStmts s1
                     loop
evalStmt (Push id1 id2 pos) =
  do head_ <- unpackInt pos   =<< getVar id1
     tail_ <- unpackStack pos =<< getVar id2
     setVar id2 $ JStack $ head_ : tail_
     setVar id1 $ JInt 0
evalStmt (Pop id1 id2 pos) =
  do head_ <- unpackInt pos   =<< getVar id1
     tail_ <- unpackStack pos =<< getVar id2
     if head_ /= 0
       then pos <!!> popToNonZero id1
       else case tail_ of
         (x:xs) -> setVar id1 (JInt x) >> setVar id2 (JStack xs)
         []     -> pos <!!> emptyStack
evalStmt (Local assign1 stmts assign2@(_, Ident _ pos, _) _) =
  do checkIdentAndType assign1 assign2
     createBinding assign1
     evalStmts stmts
     assertBinding assign2
  where createBinding (typ, id_, expr) =
          do val <- evalModularExpr expr
             checkType typ val
             bindVar id_ val
        assertBinding (_, id_, expr) =
          do val <- evalModularExpr expr
             val' <- getVar id_
             unless (val == val') $
               pos <!!> wrongDelocalValue id_ (show val) (show val')
             unbindVar id_
        checkIdentAndType (typ1, id1, _) (typ2, id2, _) =
          do unless (id1 == id2) $
               pos <!!> delocalNameMismatch id1 id2
             unless (typ1 == typ2) $
               pos <!!> delocalTypeMismatch id1 (show typ1) (show typ2)
evalStmt (Call funId args _) =
  do proc <- getProc funId
     evalProc proc args
evalStmt (Uncall funId args _) =
  do proc <- getProc funId
     evalProc (invertProc proc) args
evalStmt (Swap id1 id2 pos) =
  do leftvar  <- getvartoswap id1
     rightvar <- getvartoswap id2

     bind2 checkTypes (extractType' (id1, leftvar)) (extractType' (id2, rightvar))

     setval leftvar  $ extractval rightvar
     setval rightvar $ extractval leftvar
  where
    {-
     -getvartoswap :: Lval
     -                -> Eval (Either
     -                          (Ident, Either Integer (Fixed E12))
     -                          (Ident, Integer, ArrayRaw, Either Integer (Fixed E12), JType))
     -}
    getvartoswap (Var id_) = Left . (,) id_ <$> (getVar id_ >>= unpackIntFloat pos)
    getvartoswap (Lookup id_ idxExpr) =
      do idx      <- unpackInt pos =<< evalModularAliasExpr (Var id_) idxExpr
         (arr, t) <- unpackArray' pos =<< getVar id_
         val      <- unpackIntFloat pos =<< arrayLookup arr idx (getExprPos idxExpr)
         pure $ Right (id_, idx, arr, val, t)

    {-
     -setval :: Either (Ident, Either Integer (Fixed E12)) (Ident, Integer, ArrayRaw, Either Integer (Fixed E12), JType)
     -       -> Either Integer (Fixed E12) -> Eval ()
     -}
    setval (Left  (id_, _)) (Left val)  = setVar id_ $ JInt val
    setval (Left  (id_, _)) (Right val) = setVar id_ $ JFloat val
    setval (Right (id_, idx, arr, _, t)) val = setVar id_ $ JArray t $ arrayModify arr idx val

    extractval (Left (_,val))        = val
    extractval (Right (_,_,_,val,_)) = val

    extractType' (Var v, _)  = extractType <$> getVar v
    extractType' (Lookup{}, Right (_,_,_,_,t)) = pure t

    bind2 f a b = a >>= \r1 -> b >>= \r2 -> f r1 r2

    checkTypes a b = if a == b
                        then pure ()
                        else pos <!!> swapTypeError (showType a) (showType b)

evalStmt (UserError msg [] pos) = pos <!!> userError msg
evalStmt (UserError msg exprs pos) =
  do varList' <- varList
     case printfRender [msg] varList' of
       Right str -> pos <!!> userError str
       Left  err -> pos <!!> err
  where varList =
          mapM makeValPair exprs
        makeValPair var =
          do val <- evalModularExpr var
             return (show val, showValueType val)

evalStmt (Prints (Print msg) _) =
  liftIO $ putStrLn msg

evalStmt (Prints (Printf msg []) pos) = evalStmt $ Prints (Print msg) pos
evalStmt (Prints (Printf msg vars) pos) =
  do varList' <- varList
     case printfRender [msg] varList' of
       Right str -> liftIO $ putStrLn str
       Left  err -> pos <!!> err
  where varList =
          mapM makeValPair vars
        makeValPair var =
          do val <- evalModularExpr var
             return (show val, showValueType val)

evalStmt (Prints (Show vars) _) =
  do strs <- mapM showVar vars
     liftIO $ putStrLn $ intercalate ", " strs
  where showVar :: Ident -> Eval String
        showVar var = fmap (printVdecl (ident var)) (getVar var)

evalStmt (Skip _) = return ()

evalLval :: Maybe Lval -> Lval -> Eval Value
evalLval lv (Var id_) = checkLvalAlias lv (Var id_) >> getVar id_
evalLval lv (Lookup id_@(Ident _ pos) e) =
  do idx <- unpackInt (getExprPos e) =<< evalModularExpr e
     checkLvalAlias lv (Lookup id_ (Number idx (getExprPos e)))
     (arr, _) <- unpackArray' pos =<< getVar id_
     arrayLookup arr idx pos

numberToModular :: Value -> Eval Value
numberToModular (JInt x) =
  do flag <- asks (modInt . evalOptions)
     return $ JInt $ if flag then ((x + 2^31) `mod` 2^32) - 2^31 else x
numberToModular val = return val


evalModularExpr :: Expr -> Eval Value
evalModularExpr expr = evalExpr Nothing expr >>= numberToModular

evalModularAliasExpr :: Lval -> Expr -> Eval Value
evalModularAliasExpr lv expr = evalExpr (Just lv) expr >>= numberToModular

findAlias :: Ident -> Ident -> Eval ()
findAlias id1 id2@(Ident _ pos) =
  do aliasSet <- asks aliases
     when (isAlias aliasSet (ident id1) (ident id2)) $
       pos <!!> aliasError id1 id2

checkAlias :: Maybe Lval -> Ident -> Eval ()
checkAlias Nothing _                 = return ()
checkAlias (Just (Var id_)) id2      = findAlias id_ id2
checkAlias (Just (Lookup id_ _)) id2 = findAlias id_ id2

checkLvalAlias :: Maybe Lval -> Lval -> Eval ()
checkLvalAlias Nothing _ = return ()
checkLvalAlias (Just (Var id_)) (Var id2) = findAlias id_ id2
checkLvalAlias (Just (Var id_)) (Lookup id2 _) = findAlias id_ id2
checkLvalAlias (Just (Lookup id_ _)) (Var id2) = findAlias id_ id2
checkLvalAlias (Just (Lookup id_ (Number n _))) (Lookup id2 (Number m _))
  | n == m = findAlias id_ id2
  | otherwise = return ()


evalExpr :: Maybe Lval -> Expr -> Eval Value
evalExpr _ (Number x _)       = return $ JInt x
evalExpr _ (NumberF x _)      = return . JFloat . read . show $ x -- TODO: write your own parser for this floating number
evalExpr _ (Boolean b _)      = return $ JBool b
evalExpr _ (Nil _)            = return nil
evalExpr lv expr@(LV val _)   = inExpression expr $ evalLval lv val
evalExpr lv expr@(UnaryOp Not e) = inExpression expr $
  JBool . not <$> (unpackBool (getExprPos e) =<< evalExpr lv e)
evalExpr lv expr@(BinOp LAnd e1 e2) = inExpression expr $
  do x <- unpackBool (getExprPos e1) =<< evalExpr lv e1
     if x
        then JBool <$> (unpackBool (getExprPos e2) =<< evalExpr lv e2)
       else return $ JBool False
evalExpr lv expr@(BinOp LOr e1 e2) = inExpression expr $
  do x <- unpackBool (getExprPos e1) =<< evalExpr lv e1
     if x
       then return $ JBool True
       else fmap JBool $ unpackBool (getExprPos e2) =<< evalExpr lv e2
evalExpr lv expr@(BinOp op e1 e2) = inExpression expr $
  do x <- evalExpr lv e1
     y <- evalExpr lv e2
     performOperation op x y (getExprPos e1) (getExprPos e2)
evalExpr lv (Top id_ pos) = inArgument "top" (ident id_) $
  do checkAlias lv id_
     stack <- unpackStack pos =<< getVar id_
     case stack of
       (x:_) -> return $ JInt x
       []    -> return nil
evalExpr lv (Empty id_ pos) = inArgument "empty" (ident id_) $
  do checkAlias lv id_
     stack <- unpackStack pos =<< getVar id_
     case stack of
       [] -> return $ JBool True
       _  -> return $ JBool False
evalExpr _ (Size id_@(Ident _ pos) _) = inArgument "size" (ident id_) $
  do boxedVal <- getVar id_
     case boxedVal of
       JArray _ xs -> return $ JInt (toInteger $ lenArrayRaw xs)
       JStack xs -> return $ JInt (toInteger $ length xs)
       val       -> pos <!!> typeMismatch ["array", "stack"] (showValueType val)
