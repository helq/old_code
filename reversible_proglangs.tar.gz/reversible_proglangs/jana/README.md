
# Jana

An interpreter for Janus, the reversible programming language.

## Build and Installation

To build Jana run

    cabal configure
    cabal build

and to install

    cabal install

The program can also be run (assuming all dependencies are installed) by cd'ing
to `src` and then running

    runhaskell Main.hs

For more info about `cabal` see http://www.haskell.org/cabal/.
